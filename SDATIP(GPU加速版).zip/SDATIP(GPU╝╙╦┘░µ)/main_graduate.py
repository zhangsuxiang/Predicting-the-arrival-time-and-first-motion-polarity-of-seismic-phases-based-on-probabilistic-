import numpy as np
import cupy as cp
import os
import glob
import obspy
from datetime import datetime
import multiprocessing as mp
from functools import partial
import traceback
import psutil
import gc
from single import solutionset
import logging

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# 配置参数
BATCH_SIZE = 10  # 每批处理的波形文件数量
MAX_WORKERS = mp.cpu_count() - 2  # 最大工作进程数
MEMORY_THRESHOLD = 80  # 内存使用率阈值(%)

def check_memory():
    """检查当前内存使用率"""
    return psutil.virtual_memory().percent

def clear_gpu_memory():
    """清理GPU内存"""
    try:
        mempool = cp.get_default_memory_pool()
        pinned_mempool = cp.get_default_pinned_memory_pool()
        mempool.free_all_blocks()
        pinned_mempool.free_all_blocks()
    except Exception as e:
        logging.warning(f"GPU memory cleanup warning: {e}")

def process_single_waveform(args):
    """处理单个波形文件的包装函数"""
    sac_file, event_name, output_event_dir = args
    
    try:
        # 提取波形文件名（不含路径和扩展名）
        waveform_name = os.path.splitext(os.path.basename(sac_file))[0]
        full_name = f"{event_name}_{waveform_name}"
        
        logging.info(f"Processing: {sac_file}")
        
        # 读取地震波形数据
        st = obspy.read(sac_file)
        syntheticdata = st[0].data
        
        # 创建进程执行分析
        p = mp.Process(target=solutionset, args=(full_name, syntheticdata, output_event_dir))
        p.start()
        p.join(timeout=1200)  # 20分钟超时
        
        if p.is_alive():
            p.terminate()
            p.join()
            logging.error(f"Timeout processing: {sac_file}")
            return False, sac_file, "Timeout"
        
        if p.exitcode != 0:
            logging.error(f"Error processing: {sac_file}, exit code: {p.exitcode}")
            return False, sac_file, f"Exit code: {p.exitcode}"
        
        return True, sac_file, "Success"
        
    except Exception as e:
        logging.error(f"Exception processing {sac_file}: {str(e)}")
        logging.error(traceback.format_exc())
        return False, sac_file, str(e)

def process_event_batch(event_dir, output_base_dir, batch_files):
    """处理一个事件的一批波形文件"""
    event_name = os.path.basename(event_dir)
    output_event_dir = os.path.join(output_base_dir, event_name)
    
    # 创建输出目录
    os.makedirs(output_event_dir, exist_ok=True)
    
    # 准备参数列表
    args_list = [(sac_file, event_name, output_event_dir) for sac_file in batch_files]
    
    # 串行处理（为了更好的内存控制）
    results = []
    for args in args_list:
        result = process_single_waveform(args)
        results.append(result)
        
        # 检查内存
        if check_memory() > MEMORY_THRESHOLD:
            logging.warning(f"Memory usage high ({check_memory():.1f}%), cleaning up...")
            gc.collect()
            clear_gpu_memory()
    
    return results

def process_all_events(input_dir, output_dir):
    """处理所有地震事件"""
    # 获取所有事件文件夹
    event_dirs = [d for d in glob.glob(os.path.join(input_dir, "*")) if os.path.isdir(d)]
    event_dirs.sort()
    
    if not event_dirs:
        logging.error(f"No event directories found in {input_dir}")
        return
    
    logging.info(f"Found {len(event_dirs)} event directories")
    
    # 统计信息
    total_processed = 0
    total_failed = 0
    failed_files = []
    
    # 记录开始时间
    start_time = datetime.now()
    
    # 处理每个事件
    for event_idx, event_dir in enumerate(event_dirs):
        event_name = os.path.basename(event_dir)
        logging.info(f"\n{'='*60}")
        logging.info(f"Processing event {event_idx+1}/{len(event_dirs)}: {event_name}")
        logging.info(f"{'='*60}")
        
        # 获取该事件的所有SAC文件
        sac_files = glob.glob(os.path.join(event_dir, "*.SAC"))
        sac_files.extend(glob.glob(os.path.join(event_dir, "*.sac")))
        sac_files = list(set(sac_files))  # 去重
        sac_files.sort()
        
        if not sac_files:
            logging.warning(f"No SAC files found in {event_dir}")
            continue
        
        logging.info(f"Found {len(sac_files)} SAC files in {event_name}")
        
        # 分批处理
        for i in range(0, len(sac_files), BATCH_SIZE):
            batch_files = sac_files[i:i+BATCH_SIZE]
            batch_num = i // BATCH_SIZE + 1
            total_batches = (len(sac_files) + BATCH_SIZE - 1) // BATCH_SIZE
            
            logging.info(f"Processing batch {batch_num}/{total_batches} ({len(batch_files)} files)")
            
            # 处理当前批次
            results = process_event_batch(event_dir, output_dir, batch_files)
            
            # 统计结果
            for success, file_path, message in results:
                if success:
                    total_processed += 1
                else:
                    total_failed += 1
                    failed_files.append((file_path, message))
            
            # 清理内存
            gc.collect()
            clear_gpu_memory()
            
            # 显示进度
            elapsed_time = (datetime.now() - start_time).total_seconds()
            if total_processed > 0:
                avg_time = elapsed_time / total_processed
                remaining_files = sum(len(glob.glob(os.path.join(d, "*.SAC")) + 
                                         glob.glob(os.path.join(d, "*.sac"))) 
                                    for d in event_dirs[event_idx:]) - (len(sac_files) - i - len(batch_files))
                eta = remaining_files * avg_time
                logging.info(f"Progress: {total_processed} processed, {total_failed} failed, "
                           f"ETA: {eta/60:.1f} minutes")
    
    # 最终统计
    total_time = (datetime.now() - start_time).total_seconds()
    logging.info(f"\n{'='*60}")
    logging.info(f"PROCESSING COMPLETED")
    logging.info(f"{'='*60}")
    logging.info(f"Total time: {total_time/60:.1f} minutes")
    logging.info(f"Total processed: {total_processed}")
    logging.info(f"Total failed: {total_failed}")
    logging.info(f"Average time per file: {total_time/max(total_processed,1):.1f} seconds")
    
    # 保存失败文件列表
    if failed_files:
        failed_log = os.path.join(output_dir, "failed_files.log")
        with open(failed_log, 'w', encoding='utf-8') as f:
            f.write(f"Failed files report - {datetime.now()}\n")
            f.write(f"{'='*60}\n")
            for file_path, message in failed_files:
                f.write(f"{file_path}: {message}\n")
        logging.info(f"Failed files list saved to: {failed_log}")

def main():
    """主程序入口"""
    # 检查GPU
    try:
        gpu_count = cp.cuda.runtime.getDeviceCount()
        if gpu_count > 0:
            # 修复：安全获取GPU属性
            try:
                device_props = cp.cuda.runtime.getDeviceProperties(0)
                
                # 获取GPU名称
                try:
                    if hasattr(device_props, 'name'):
                        gpu_name_raw = device_props.name
                    elif isinstance(device_props, dict) and 'name' in device_props:
                        gpu_name_raw = device_props['name']
                    else:
                        gpu_name_raw = "GPU 0"
                    
                    if isinstance(gpu_name_raw, bytes):
                        gpu_name = gpu_name_raw.decode('utf-8', errors='replace')
                    else:
                        gpu_name = str(gpu_name_raw)
                    
                    gpu_name = ''.join(c for c in gpu_name if c.isprintable())
                except:
                    gpu_name = "Unknown GPU"
                
                # 获取GPU内存
                try:
                    if hasattr(device_props, 'totalGlobalMem'):
                        gpu_memory = device_props.totalGlobalMem / 1024**3
                    elif isinstance(device_props, dict) and 'totalGlobalMem' in device_props:
                        gpu_memory = device_props['totalGlobalMem'] / 1024**3
                    else:
                        gpu_memory = 0
                except:
                    gpu_memory = 0
                
                logging.info(f"GPU detected: {gpu_name} ({gpu_memory:.1f} GB)")
            except Exception as e:
                logging.warning(f"GPU property detection failed: {e}")
                logging.info("GPU detected but properties unavailable")
        else:
            logging.info("No GPU detected, using CPU")
    except Exception as e:
        logging.warning(f"GPU detection failed: {e}")
        logging.info("Using CPU instead")
    
    # 设置输入输出目录
    input_dir = os.path.join('.', 'input')
    output_dir = os.path.join('.', 'output')
    
    # 确保目录存在
    if not os.path.exists(input_dir):
        logging.error(f"Input directory not found: {input_dir}")
        return
    
    os.makedirs(output_dir, exist_ok=True)
    
    # 显示配置
    logging.info(f"\nConfiguration:")
    logging.info(f"  Input directory: {input_dir}")
    logging.info(f"  Output directory: {output_dir}")
    logging.info(f"  Batch size: {BATCH_SIZE}")
    logging.info(f"  Memory threshold: {MEMORY_THRESHOLD}%")
    logging.info(f"  Current memory usage: {check_memory():.1f}%")
    
    # 开始处理
    process_all_events(input_dir, output_dir)

if __name__ == '__main__':
    mp.freeze_support()
    main()