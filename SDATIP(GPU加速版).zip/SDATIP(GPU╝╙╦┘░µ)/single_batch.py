# single_batch.py - 批处理优化版本
import os
import numpy as np
import cupy as cp
import scipy.io as scio
from Waveform import Waveform
import plotresult
import plotresult_graduate_1
import gc
import logging

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def clear_memory():
    """清理内存"""
    gc.collect()
    try:
        mempool = cp.get_default_memory_pool()
        pinned_mempool = cp.get_default_pinned_memory_pool()
        mempool.free_all_blocks()
        pinned_mempool.free_all_blocks()
    except:
        pass

def solutionset(name, data, outputdir, skip_plots=False, save_intermediate=True):
    """
    对单一波形数据执行全流程分析（批处理优化版本）：
      - skip_plots: 是否跳过绘图（批处理时可选）
      - save_intermediate: 是否保存中间结果
    """
    try:
        # 1. 确保输出目录存在
        outputdir = os.path.normpath(outputdir)
        os.makedirs(outputdir, exist_ok=True)
        
        # 检查GPU可用性（简化版，减少输出）
        use_gpu = False
        try:
            gpu_count = cp.cuda.runtime.getDeviceCount()
            if gpu_count > 0:
                use_gpu = True
        except:
            use_gpu = False
        
        logging.debug(f"[1/4] Processing {name!r} (GPU: {use_gpu})")
        
        # 2. 数据导入与预处理
        a = Waveform(name, use_gpu=use_gpu)
        a.importdata(data, 0.01)
        a.analyzedata()
        a.interpolate(1)
        a.denseunique()
        a.denselong(2.5, 200)
        a.extremearr()
        a.densebin()
        logging.debug("    ➤ Preprocessing completed")
        
        # 3. 构建状态并计算矩阵与概率
        b = a.constructstate()
        c, c_num = b.markovmatrix()
        d = b.ampprobcalculate()
        logging.debug("    ➤ Markov matrix and amplitude probability calculated")
        
        # 4. 保存总体 .mat（将GPU数据转到CPU）
        if save_intermediate:
            summary_mat = os.path.join(outputdir, f"{a.name}.mat")
            
            # 确保数据在CPU上
            matrix_cpu = b.matrix if isinstance(b.matrix, np.ndarray) else cp.asnumpy(b.matrix)
            ampprob_cpu = np.array(b.ampprob_up, dtype=np.float64)
            
            # 安全处理其他数据
            threshold_cpu = a.threshold if isinstance(a.threshold, np.ndarray) else (
                cp.asnumpy(a.threshold) if hasattr(a, 'threshold') and isinstance(a.threshold, cp.ndarray) else np.array([])
            )
            
            Apeak_cpu = b.Apeak if isinstance(b.Apeak, (list, np.ndarray)) else cp.asnumpy(b.Apeak)
            eigvalue_cpu = b.eigvalue if isinstance(b.eigvalue, np.ndarray) else cp.asnumpy(b.eigvalue)
            bigeig_cpu = b.bigeig if isinstance(b.bigeig, np.ndarray) else cp.asnumpy(b.bigeig)
            
            scio.savemat(
                summary_mat,
                {
                    "transitionmatrix": matrix_cpu,
                    "ampprob": ampprob_cpu,
                    "Apeak": Apeak_cpu,
                    "samplelength": b.samplength,
                    "eigvalue": eigvalue_cpu,
                    "bigeig": bigeig_cpu,
                    "threshold": threshold_cpu,
                }
            )
            logging.debug(f"    ➤ Saved summary MAT: {summary_mat}")
        
        # 5. 创建结果汇总
        results_summary = {
            'name': name,
            'num_solutions': c_num,
            'solutions': []
        }
        
        # 6. 打开日志文件
        log_path = os.path.join(outputdir, f"{name}_results.txt")
        with open(log_path, "w", encoding='utf-8') as f_log:
            # 写入头部信息
            f_log.write(f"Analysis results for: {name}\n")
            f_log.write(f"Number of solutions: {c_num}\n")
            f_log.write(f"{'='*80}\n")
            
            # 7. 逐个解处理
            for i in range(c_num):
                b.estimation(i)
                
                # 7.1 保存 timeprob.mat
                if save_intermediate:
                    timeprob_mat = os.path.join(outputdir, f"{a.name}_timeprob_{i}.mat")
                    timeprob_data = c[i] if isinstance(c[i], np.ndarray) else cp.asnumpy(c[i])
                    scio.savemat(timeprob_mat, {"timeprob": timeprob_data})
                    logging.debug(f"    ➤ Saved timeprob MAT({i}): {timeprob_mat}")
                
                # 7.2 绘图（可选）
                if not skip_plots:
                    try:
                        # 确保数据在CPU上进行绘图
                        if use_gpu and hasattr(a, 'use_gpu') and a.use_gpu:
                            # 创建CPU版本用于绘图
                            a_cpu = create_cpu_waveform(a)
                            plotresult.plotprob(a_cpu, b, i, a.name, outputdir)
                            plotresult_graduate_1.plotprob(a_cpu, b, i, a.name, outputdir)
                            del a_cpu  # 立即释放内存
                        else:
                            plotresult.plotprob(a, b, i, a.name, outputdir)
                            plotresult_graduate_1.plotprob(a, b, i, a.name, outputdir)
                    except Exception as e:
                        logging.warning(f"Failed to create plots for solution {i}: {str(e)}")
                
                # 7.3 计算统计信息
                c_i_cpu = c[i] if isinstance(c[i], np.ndarray) else cp.asnumpy(c[i])
                d_cpu = d if isinstance(d, np.ndarray) else cp.asnumpy(d)
                overall_up = float(np.sum(c_i_cpu * d_cpu))
                
                # 保存解的信息
                solution_info = {
                    'id': i,
                    'arrivaltime': b.arrivalestimate,
                    'overall_up': overall_up,
                    'polarity_up': b.polarityup,
                    'polarity_down': b.polaritydown,
                    'polarity_unknown': b.polarityunknown,
                    'Apeak': b.Apeakestimate,
                    'sigma': b.sigmaestimate
                }
                results_summary['solutions'].append(solution_info)
                
                # 7.4 写日志
                log_line = (
                    f"Solution {i:3d}: "
                    f"arrival={b.arrivalestimate:8.3f}s, "
                    f"Apeak={b.Apeakestimate:8.3f}, "
                    f"sigma={b.sigmaestimate:8.3f}, "
                    f"overall_up={overall_up:6.4f}, "
                    f"up={b.polarityup:5.3f}, "
                    f"down={b.polaritydown:5.3f}, "
                    f"unknown={b.polarityunknown:5.3f}\n"
                )
                f_log.write(log_line)
            
            # 写入最佳解信息
            if results_summary['solutions']:
                f_log.write(f"\n{'='*80}\n")
                f_log.write("Best solution (highest overall_up):\n")
                best_solution = max(results_summary['solutions'], key=lambda x: x['overall_up'])
                f_log.write(f"  Solution ID: {best_solution['id']}\n")
                f_log.write(f"  Arrival time: {best_solution['arrivaltime']:.3f}s\n")
                f_log.write(f"  Polarity: {'UP' if best_solution['polarity_up'] > 0.5 else 'DOWN'}\n")
                f_log.write(f"  Confidence: {max(best_solution['polarity_up'], best_solution['polarity_down']):.3f}\n")
        
        logging.info(f"✓ Completed: {name} ({c_num} solutions)")
        
        # 8. 清理内存
        del a, b, c, d
        clear_memory()
        
        return True, results_summary
        
    except Exception as e:
        logging.error(f"✗ Failed: {name} - {str(e)}")
        clear_memory()
        return False, str(e)

def create_cpu_waveform(a_gpu):
    """创建GPU波形对象的CPU副本（用于绘图）"""
    a_cpu = Waveform(a_gpu.name, use_gpu=False)
    
    # 复制必要的属性到CPU版本
    essential_attrs = [
        'data', 'denselongdata', 'longtimestamp', 'timestamp', 
        'densetimestamp', 'cut', 'threshold', 'densedata',
        'longextremearr', 'dense_abs', 'denselongabs'
    ]
    
    for attr in essential_attrs:
        if hasattr(a_gpu, attr):
            val = getattr(a_gpu, attr)
            if isinstance(val, cp.ndarray):
                setattr(a_cpu, attr, cp.asnumpy(val))
            else:
                setattr(a_cpu, attr, val)
    
    # 复制标量属性
    scalar_attrs = [
        'longlength', 'length', 'name', 'time', 'maxamp', 
        'minamp', 'maxampindex', 'minampindex', 'delta', 
        'densedelta', 'num', 'mean', 'median', 'above0', 
        'below0', 'denselength', 'denseco'
    ]
    
    for attr in scalar_attrs:
        if hasattr(a_gpu, attr):
            setattr(a_cpu, attr, getattr(a_gpu, attr))
    
    return a_cpu

# 批处理专用函数
def batch_process_waveforms(waveform_list, output_base_dir, skip_plots=True, max_batch=50):
    """
    批量处理波形列表
    
    Parameters:
    -----------
    waveform_list : list of tuples
        [(name, data, output_dir), ...]
    output_base_dir : str
        基础输出目录
    skip_plots : bool
        是否跳过绘图（加快处理速度）
    max_batch : int
        每批最大处理数量
    
    Returns:
    --------
    results : list
        处理结果列表
    """
    results = []
    total = len(waveform_list)
    
    for i in range(0, total, max_batch):
        batch = waveform_list[i:i+max_batch]
        logging.info(f"Processing batch {i//max_batch + 1}/{(total + max_batch - 1)//max_batch}")
        
        for name, data, output_dir in batch:
            success, result = solutionset(name, data, output_dir, skip_plots=skip_plots)
            results.append((name, success, result))
        
        # 批次间清理内存
        clear_memory()
    
    return results