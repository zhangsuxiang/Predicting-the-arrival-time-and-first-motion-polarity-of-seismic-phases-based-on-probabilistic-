# Waveform.py - GPU accelerated version with memory management
import numpy as np
import cupy as cp
import obspy
from cupyx.scipy.signal import argrelextrema as cp_argrelextrema
from scipy.signal import argrelextrema as np_argrelextrema
import pmi
import State
import os
import gc

class Waveform():
    def __init__(self, name, use_gpu=True):
        self.name = name
        self.num = 1
        self.use_gpu = use_gpu and cp.cuda.is_available()
        self.xp = cp if self.use_gpu else np
        
    def __del__(self):
        """析构函数 - 清理GPU内存"""
        if hasattr(self, 'use_gpu') and self.use_gpu:
            try:
                # 将所有GPU数组属性设为None
                gpu_attrs = ['data', 'densedata', 'denselongdata', 
                           'timestamp', 'densetimestamp', 'longtimestamp',
                           'dense_abs', 'dense_abs_unique', 'denselongabs',
                           'longextremearr', 'extrememax', 'extrememin',
                           'extremeall', 'denseextrememax', 'denseextrememin',
                           'denseextremeall', 'longextrememax', 'longextrememin',
                           'longextremeall', 'dataindexinlong', 'dataindexindense',
                           'threshold', 'cut']
                
                for attr in gpu_attrs:
                    if hasattr(self, attr):
                        setattr(self, attr, None)
                
                # 清理GPU内存池
                mempool = cp.get_default_memory_pool()
                mempool.free_all_blocks()
            except:
                pass
        
        # 强制垃圾回收
        gc.collect()
        
    def _to_gpu(self, data):
        """将数据移到GPU"""
        if self.use_gpu and not isinstance(data, cp.ndarray):
            return cp.asarray(data)
        return data
    
    def _to_cpu(self, data):
        """将数据移到CPU"""
        if isinstance(data, cp.ndarray):
            return cp.asnumpy(data)
        return data
    
    def clear_memory(self):
        """手动清理内存"""
        # 清理大型数组
        large_attrs = ['data', 'densedata', 'denselongdata', 'longextremearr']
        for attr in large_attrs:
            if hasattr(self, attr):
                if isinstance(getattr(self, attr), cp.ndarray):
                    setattr(self, attr, self._to_cpu(getattr(self, attr)))
        
        # GPU内存清理
        if self.use_gpu:
            try:
                mempool = cp.get_default_memory_pool()
                pinned_mempool = cp.get_default_pinned_memory_pool()
                mempool.free_all_blocks()
                pinned_mempool.free_all_blocks()
            except:
                pass
        
        gc.collect()
    
    def importdata(self, data, delta):
        """导入数据并转移到GPU"""
        self.data = self._to_gpu(data)
        self.delta = delta
        self.length = len(self.data)
        self.timestamp = self.xp.linspace(0, self.delta * (self.length - 1), self.length)
    
    def importdatafromsac(self, filename):
        """从SAC文件导入数据（Windows兼容路径）"""
        # 确保路径Windows兼容
        filename = os.path.normpath(filename)
        a = obspy.read(filename)
        self.data = self._to_gpu(a[0].data)
        self.delta = a[0].stats.delta
        self.length = len(self.data)
        self.timestamp = self.xp.linspace(0, self.delta * (self.length - 1), self.length)
    
    def analyzedata(self):
        """分析数据的基本统计信息"""
        self.mean = float(self.xp.mean(self.data))
        self.median = float(self.xp.median(self.data))
        
        # 极值点查找（GPU加速）
        if self.use_gpu:
            # 转到CPU进行极值查找（CuPy的argrelextrema支持有限）
            data_cpu = self._to_cpu(self.data)
            self.extrememax = np_argrelextrema(data_cpu, np.greater_equal)[0]
            self.extrememin = np_argrelextrema(-1 * data_cpu, np.greater_equal)[0]
            self.extrememax = self._to_gpu(self.extrememax)
            self.extrememin = self._to_gpu(self.extrememin)
        else:
            self.extrememax = np_argrelextrema(self.data, np.greater_equal)[0]
            self.extrememin = np_argrelextrema(-1 * self.data, np.greater_equal)[0]
        
        self.extremeall = self.xp.sort(self.xp.append(self.extrememax, self.extrememin))
        self.above0 = int(self.xp.sum(self.data > 0))
        self.below0 = int(self.xp.sum(self.data < 0))
    
    def rmmean(self):
        """去除均值"""
        self.data = self.data - self.mean
        self.above0 = int(self.xp.sum(self.data > 0))
        self.below0 = int(self.xp.sum(self.data < 0))
    
    def rmtail(self):
        """去除尾部"""
        self.data = self.data[0:self.extremeall[-2] + 1]
        self.extremeall = self.extremeall[0:-1]
        self.length = len(self.data)
        
        if self.use_gpu:
            data_cpu = self._to_cpu(self.data)
            self.extrememax = np_argrelextrema(data_cpu, np.greater_equal)[0]
            self.extrememin = np_argrelextrema(-1 * data_cpu, np.greater_equal)[0]
            self.extrememax = self._to_gpu(self.extrememax)
            self.extrememin = self._to_gpu(self.extrememin)
        else:
            self.extrememax = np_argrelextrema(self.data, np.greater_equal)[0]
            self.extrememin = np_argrelextrema(-1 * self.data, np.greater_equal)[0]
        
        self.above0 = int(self.xp.sum(self.data > 0))
        self.below0 = int(self.xp.sum(self.data < 0))
    
    def interpolate(self, coefficient):
        """GPU加速的插值"""
        self.densedelta = self.delta / coefficient
        self.denselength = self.length + (self.length - 1) * (coefficient - 1)
        self.densetimestamp = self.xp.linspace(0, self.densedelta * (self.denselength - 1), self.denselength)
        
        # GPU加速的插值
        if self.use_gpu:
            # CuPy的interp实现
            self.densedata = cp.interp(self.densetimestamp, self.timestamp, self.data)
        else:
            self.densedata = np.interp(self.densetimestamp, self.timestamp, self.data)
        
        # 极值点查找
        if self.use_gpu:
            data_cpu = self._to_cpu(self.densedata)
            self.denseextrememax = np_argrelextrema(data_cpu, np.greater_equal)[0]
            self.denseextrememin = np_argrelextrema(-1 * data_cpu, np.greater_equal)[0]
            self.denseextrememax = self._to_gpu(self.denseextrememax)
            self.denseextrememin = self._to_gpu(self.denseextrememin)
        else:
            self.denseextrememax = np_argrelextrema(self.densedata, np.greater_equal)[0]
            self.denseextrememin = np_argrelextrema(-1 * self.densedata, np.greater_equal)[0]
        
        self.denseextremeall = self.xp.unique(self.xp.append(self.denseextrememax, self.denseextrememin))
        self.denseco = coefficient
        self.dataindexindense = self.xp.arange(0, self.denselength - 1 + self.denseco, self.denseco)
    
    def denseunique(self):
        """GPU加速的唯一值查找"""
        self.dense_abs = self.xp.abs(self.densedata)
        self.dense_abs_unique = self.xp.unique(self.dense_abs)
        
        dense_abs_unique_index = []
        for i in range(len(self.dense_abs_unique)):
            indices = self.xp.where(self.dense_abs == self.dense_abs_unique[i])[0]
            dense_abs_unique_index.append(indices)
        
        self.dense_abs_unique_index = dense_abs_unique_index
        self.threshold = self.dense_abs_unique
    
    def denselong(self, hvcoefficient, mininsertco):
        """GPU加速的密集化处理"""
        hunit = hvcoefficient * (float(self.xp.max(self.data)) - float(self.xp.min(self.data))) / (self.length - 1)
        vchange = self.xp.abs(self.data[1:] - self.data[0:-1])
        
        # 初始化为列表以便动态扩展
        longtimestamp_list = []
        dataindexinlong_list = []
        
        timestamp_cpu = self._to_cpu(self.timestamp)
        vchange_cpu = self._to_cpu(vchange)
        
        for i in range(self.length - 1):
            insertpointnumber = int(np.round(np.sqrt(vchange_cpu[i]**2 + hunit**2) * mininsertco / hunit))
            insertvector = np.linspace(timestamp_cpu[i], timestamp_cpu[i + 1], insertpointnumber + 1)
            
            if i < self.length - 2:
                dataindexinlong_list.append(len(longtimestamp_list))
                longtimestamp_list.extend(insertvector[0:-1])
            else:
                dataindexinlong_list.append(len(longtimestamp_list))
                longtimestamp_list.extend(insertvector)
                dataindexinlong_list.append(len(longtimestamp_list) - 1)
        
        # 转换回数组并移到GPU
        self.longtimestamp = self._to_gpu(np.array(longtimestamp_list))
        self.dataindexinlong = self._to_gpu(np.array(dataindexinlong_list))
        
        # GPU插值
        if self.use_gpu:
            self.denselongdata = cp.interp(self.longtimestamp, self.timestamp, self.data)
        else:
            self.denselongdata = np.interp(self.longtimestamp, self.timestamp, self.data)
        
        self.denselongabs = self.xp.abs(self.denselongdata)
        self.longlength = len(self.denselongdata)
        
        # 极值点查找
        if self.use_gpu:
            data_cpu = self._to_cpu(self.denselongdata)
            self.longextrememax = np_argrelextrema(data_cpu, np.greater_equal)[0]
            self.longextrememin = np_argrelextrema(-1 * data_cpu, np.greater_equal)[0]
            self.longextrememax = self._to_gpu(self.longextrememax)
            self.longextrememin = self._to_gpu(self.longextrememin)
        else:
            self.longextrememax = np_argrelextrema(self.denselongdata, np.greater_equal)[0]
            self.longextrememin = np_argrelextrema(-1 * self.denselongdata, np.greater_equal)[0]
        
        self.longextremeall = self.xp.unique(self.xp.append(self.longextrememax, self.longextrememin))
        self.hvcoefficient = hvcoefficient
        self.mininsertco = mininsertco
    
    def extremearr(self):
        """GPU加速的极值数组构建"""
        self.longextremearr = self.xp.zeros(self.longlength)
        
        for i in range(1, len(self.longextremeall)):
            idx_prev = int(self.longextremeall[i - 1])
            idx_curr = int(self.longextremeall[i])
            
            if self.denselongdata[idx_curr] * self.denselongdata[idx_prev] > 0:
                if self.denselongabs[idx_curr] >= self.denselongabs[idx_prev]:
                    self.longextremearr[idx_prev:idx_curr + 1] = self.denselongabs[idx_curr]
                else:
                    self.longextremearr[idx_prev:idx_curr + 1] = self.denselongabs[idx_prev]
            else:
                signarray = self.denselongdata[idx_prev:idx_curr] * self.denselongdata[idx_prev + 1:idx_curr + 1]
                turnpoint = int(self.xp.where(signarray <= 0)[0][0]) + 1
                self.longextremearr[idx_prev:idx_prev + turnpoint] = self.denselongabs[idx_prev]
                self.longextremearr[idx_prev + turnpoint:idx_curr + 1] = self.denselongabs[idx_curr]
        
        self.longextremearrmin = float(self.xp.min(self.longextremearr))
    
    def densebin(self):
        """GPU加速的密度分箱"""
        longarray = self.xp.ones(self.longlength + 1)
        self.mivalue = []
        self.pmivalue = []
        self.cut = []
        self.peak = []
        self.noiselength = []
        self.noiseindex = []
        self.chances = []
        
        for i in range(len(self.threshold)):
            longarray = self.xp.ones(self.longlength + 1)
            
            if self.threshold[i] > self.longextremearrmin:
                zeroindex = self.xp.where(self.xp.abs(self.longextremearr) <= self.threshold[i])[0]
                longarray[zeroindex] = 0
                
                # PMI计算
                longarray_cpu = self._to_cpu(longarray)
                mivalue, pmivalue, longcutsolution = pmi.maxpmi(longarray_cpu, -1)
                
                if isinstance(longcutsolution, (list, np.ndarray)):
                    longcutsolution = np.array(longcutsolution)
                else:
                    longcutsolution = np.array([longcutsolution])
                
                for j in range(len(longcutsolution)):
                    if longcutsolution[j] < self.longlength:
                        longcutsolution[j] = longcutsolution[j] + 1
                        denselongabs_cpu = self._to_cpu(self.denselongabs)
                        threshold_cpu = float(self._to_cpu(self.threshold[i]))
                        cutincycle = int(np.where(denselongabs_cpu[int(longcutsolution[j]):] > threshold_cpu)[0][0])
                        longcutsolution[j] = longcutsolution[j] + cutincycle
            else:
                zeroindex = self.xp.where(self.xp.abs(self.denselongdata) <= self.threshold[i])[0]
                longarray[zeroindex] = 0
                longarray_cpu = self._to_cpu(longarray)
                mivalue, pmivalue, longcutsolution = pmi.maxpmi(longarray_cpu, -1)
                
                if not isinstance(longcutsolution, np.ndarray):
                    longcutsolution = np.array([longcutsolution])
            
            zeroindex = self.xp.where(self.xp.abs(self.denselongdata) <= self.threshold[i])[0]
            if len(zeroindex) > 0.95 * self.longlength:
                mivalue, pmivalue, longcutsolution = 0, 0, np.array([self.longlength])
            
            self.mivalue.append(mivalue)
            self.pmivalue.append(pmivalue)
            self.cut.append(longcutsolution - 1)
            
            # 处理峰值和噪声
            peakcollect = []
            noiselength = []
            noiseindex = []
            chances = []
            
            for j in range(len(longcutsolution)):
                denselongabs_cpu = self._to_cpu(self.denselongabs)
                threshold_cpu = float(self._to_cpu(self.threshold[i]))
                oriindex = np.where(denselongabs_cpu[0:int(longcutsolution[j])] <= threshold_cpu)[0]
                
                dataindexinlong_cpu = self._to_cpu(self.dataindexinlong)
                dataindexindense_cpu = self._to_cpu(self.dataindexindense)
                
                nindex, chance = findnoise(oriindex, dataindexinlong_cpu, dataindexindense_cpu, int(longcutsolution[j]) - 1)
                noiseindex.append(nindex)
                chances.append(chance)
                noiselength.append(len(noiseindex[j]))
                
                if longcutsolution[j] == self.longlength:
                    peakcollect.append(0)
                else:
                    longextremeall_cpu = self._to_cpu(self.longextremeall)
                    denselongdata_cpu = self._to_cpu(self.denselongdata)
                    idx = int(np.where(longextremeall_cpu > longcutsolution[j] - 1)[0][0])
                    peakcollect.append(denselongdata_cpu[longextremeall_cpu[idx]])
            
            self.peak.append(peakcollect)
            self.noiselength.append(noiselength)
            self.noiseindex.append(noiseindex)
            self.chances.append(chances)
    
    def constructstate(self):
        """构建状态对象"""
        state = State.State(self.name, use_gpu=self.use_gpu)
        
        threshold_cpu = self._to_cpu(self.threshold)
        densedata_cpu = self._to_cpu(self.densedata)
        longtimestamp_cpu = self._to_cpu(self.longtimestamp)
        
        for i in range(len(self.threshold)):
            if i == len(self.threshold) - 1:
                downthreshold = threshold_cpu[i]
                upthreshold = np.inf
            else:
                downthreshold = threshold_cpu[i]
                upthreshold = threshold_cpu[i + 1]
            
            if len(self.noiselength[i]) > 1:
                noisecombo = []
                for j in range(len(self.noiselength[i])):
                    noisecombo.append(densedata_cpu[self.noiseindex[i][j].astype('int')])
                state.addcombo(
                    len(self.noiselength[i]), downthreshold, upthreshold, 
                    noisecombo, self.chances[i], self.pmivalue[i], 
                    self.peak[i], longtimestamp_cpu[self.cut[i]]
                )
            else:
                state.addstate(
                    downthreshold, upthreshold, 
                    densedata_cpu[self.noiseindex[i][0].astype('int')],
                    self.chances[i], self.pmivalue[i], self.peak[i],
                    longtimestamp_cpu[self.cut[i]]
                )
        
        return state

def findnoise(oriindex, dataindexinlong, dataindexindense, cutsolution):
    """查找噪声索引"""
    noiseindex = np.array([])
    distributionrange = []
    
    if cutsolution == dataindexinlong[-1]:
        return np.arange(0, dataindexindense[-1] + 1), len(dataindexindense) - 1
    else:
        for i in range(len(dataindexinlong) - 1):
            if i < len(dataindexinlong) - 2:
                haveornot = np.where((oriindex >= dataindexinlong[i]) & 
                                   (oriindex < dataindexinlong[i + 1]))[0]
            else:
                haveornot = np.where((oriindex >= dataindexinlong[i]) & 
                                   (oriindex <= dataindexinlong[i + 1]))[0]
            if len(haveornot) > 0:
                distributionrange.append(i)
        
        if len(distributionrange) == 1:
            return np.arange(dataindexindense[distributionrange[0]], 
                           dataindexindense[distributionrange[0] + 1] + 1), 1
        else:
            for i in range(len(distributionrange) - 1):
                noiseindex = np.append(noiseindex, 
                                     np.arange(dataindexindense[distributionrange[i]], 
                                             dataindexindense[distributionrange[i] + 1] + 1))
            return np.sort(np.unique(noiseindex)), len(distributionrange)