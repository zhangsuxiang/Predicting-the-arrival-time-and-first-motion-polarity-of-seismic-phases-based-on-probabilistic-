# plotpmi.py - Windows compatible version with memory management
import numpy as np
import matplotlib
# Windows下使用默认后端
# matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pmi
import os
import gc

def ensure_cpu_data(data):
    """确保数据在CPU上（处理可能的GPU数据）"""
    try:
        import cupy as cp
        if isinstance(data, cp.ndarray):
            return cp.asnumpy(data)
    except:
        pass
    return data

def plotwaveform_dense(a, b, threshold_id, arrivaltime, pmiarray):
    """绘制密集波形的PMI分析图（带内存管理）"""
    try:
        fig = plt.figure(figsize=(16, 9))
        plt.rcParams["font.weight"] = "bold"
        plt.rcParams["axes.labelweight"] = "bold"
        
        # 确保数据在CPU上
        longtimestamp = ensure_cpu_data(a.longtimestamp)
        denselongdata = ensure_cpu_data(a.denselongdata)
        
        ax1 = fig.add_axes([0.1, 0.5, 0.8, 0.4])
        colori = np.zeros([b.num, 3])
        threshold = b.threshold[threshold_id]
        longarray = np.ones(a.longlength + 1)
        
        # 查找低于阈值的索引
        zeroindex = np.where(abs(denselongdata) <= threshold)[0]
        
        # 绘制波形
        ax1.plot(longtimestamp, denselongdata, linewidth=2.5, color='k', linestyle='-')
        ax1.plot(longtimestamp[zeroindex], denselongdata[zeroindex], 
                 linewidth=2.5, color='r', linestyle='-', alpha=0.7)
        
        # 填充阈值区域
        ax1.fill_between([0, longtimestamp[-1]], 
                         [threshold * (-1), threshold * (-1)],
                         [threshold, threshold], 
                         color='gray', alpha=0.1)
        
        # 绘制切割线
        if hasattr(a, 'longcutsolution'):
            ax1.plot(a.longcutsolution[threshold_id] * np.ones(10), 
                    np.linspace(-1 * b.upthreshold[-1], b.upthreshold[-1], 10), 
                    linewidth=2.5, color='k', linestyle='--')
        
        ax1.set(ylim=(-1 * b.upthreshold[-1], b.upthreshold[-1]))
        ax1.set_xticks(np.linspace(0, longtimestamp[-1], 5))
        ax1.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, longtimestamp[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax1.set_yticks(np.linspace(-b.upthreshold[-1], b.upthreshold[-1], 5))
        ax1.set_yticklabels(
            ['%.2f' % val for val in np.linspace(-b.upthreshold[-1], b.upthreshold[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax1.tick_params(direction='out', size=20)
        ax1.set_ylabel('Amplitude', weight='bold')
        ax1.set_xlabel('Time (s)', weight='bold')
        
        for spine in ax1.spines.values():
            spine.set_linewidth(2)
        
        # 第二个子图：PMI值
        ax2 = fig.add_axes([0.1, 0.1, 0.8, 0.3])
        
        # 计算PMI值
        longarray[zeroindex] = 0
        mivalue = np.zeros(a.longlength)
        pmivalue = np.zeros(a.longlength)
        longcutsolution_arr = np.zeros(a.longlength)
        
        for i in range(a.longlength):
            mi, pmi_val, cut = pmi.maxpmi(longarray, i)
            mivalue[i] = mi
            pmivalue[i] = pmi_val
            longcutsolution_arr[i] = cut
        
        ax2.plot(longtimestamp[:-1], pmivalue[:-1], linewidth=2.5, color='b', linestyle='-')
        ax2.set(ylim=(0, np.max(pmivalue) * 1.1))
        ax2.set_xticks(np.linspace(0, longtimestamp[-1], 5))
        ax2.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, longtimestamp[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax2.set_yticks(np.linspace(0, np.max(pmivalue) * 1.1, 5))
        ax2.set_yticklabels(
            ['%.2f' % val for val in np.linspace(0, np.max(pmivalue) * 1.1, 5)],
            {'fontweight': 'bold'}
        )
        ax2.tick_params(direction='out', size=20)
        ax2.set_ylabel('PMI Value', weight='bold')
        ax2.set_xlabel('Time (s)', weight='bold')
        
        for spine in ax2.spines.values():
            spine.set_linewidth(2)
        
        plt.tight_layout()
        
    except Exception as e:
        print(f"Error in plotwaveform_dense: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # 清理内存
        if 'fig' in locals():
            plt.close(fig)
        plt.close('all')
        gc.collect()
    
    return fig if 'fig' in locals() else None

def plotwaveform_extreme(a, b, threshold, arrivaltime, pmiarray):
    """绘制极值波形的PMI分析图（带内存管理）"""
    try:
        fig = plt.figure(figsize=(16, 9))
        plt.rcParams["font.weight"] = "bold"
        plt.rcParams["axes.labelweight"] = "bold"
        
        # 确保数据在CPU上
        longtimestamp = ensure_cpu_data(a.longtimestamp)
        denselongdata = ensure_cpu_data(a.denselongdata)
        longextremearr = ensure_cpu_data(a.longextremearr)
        
        ax1 = fig.add_axes([0.1, 0.5, 0.8, 0.4])
        
        # 查找极值数组中低于阈值的索引
        zeroindex = np.where(abs(longextremearr) <= threshold)[0]
        
        # 绘制原始波形和极值包络
        ax1.plot(longtimestamp, denselongdata, linewidth=2.5, color='k', linestyle='-', alpha=0.7)
        ax1.plot(longtimestamp, longextremearr, linewidth=2.5, color='b', linestyle='-')
        ax1.plot(longtimestamp, -longextremearr, linewidth=2.5, color='b', linestyle='-')
        
        # 填充阈值区域
        ax1.fill_between([0, longtimestamp[-1]], 
                         [-threshold, -threshold],
                         [threshold, threshold], 
                         color='gray', alpha=0.1)
        
        ax1.set(ylim=(-b.upthreshold[-1], b.upthreshold[-1]))
        ax1.set_xticks(np.linspace(0, longtimestamp[-1], 5))
        ax1.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, longtimestamp[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax1.set_yticks(np.linspace(-b.upthreshold[-1], b.upthreshold[-1], 5))
        ax1.set_yticklabels(
            ['%.2f' % val for val in np.linspace(-b.upthreshold[-1], b.upthreshold[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax1.tick_params(direction='out', size=20)
        ax1.set_ylabel('Amplitude', weight='bold')
        ax1.set_xlabel('Time (s)', weight='bold')
        ax1.set_title('Extreme Value Envelope Analysis', weight='bold')
        
        for spine in ax1.spines.values():
            spine.set_linewidth(2)
        
        # 第二个子图：PMI分析
        ax2 = fig.add_axes([0.1, 0.1, 0.8, 0.3])
        
        # 基于极值包络计算PMI
        longarray = np.ones(a.longlength + 1)
        longarray[zeroindex] = 0
        
        # 计算PMI值序列
        result = []
        for i in range(1, a.longlength):
            mi_val, pmi_val = pmi.pmi(longarray, i)
            result.append(pmi_val)
        
        if result:
            ax2.plot(longtimestamp[1:], result, linewidth=2.5, color='r', linestyle='-')
            ax2.set(ylim=(0, max(result) * 1.1))
        
        ax2.set_xticks(np.linspace(0, longtimestamp[-1], 5))
        ax2.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, longtimestamp[-1], 5)],
            {'fontweight': 'bold'}
        )
        ax2.tick_params(direction='out', size=20)
        ax2.set_ylabel('PMI Value', weight='bold')
        ax2.set_xlabel('Time (s)', weight='bold')
        
        for spine in ax2.spines.values():
            spine.set_linewidth(2)
        
        plt.tight_layout()
        
    except Exception as e:
        print(f"Error in plotwaveform_extreme: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # 清理内存
        if 'fig' in locals():
            plt.close(fig)
        plt.close('all')
        gc.collect()
    
    return fig if 'fig' in locals() else None

def plotmatrix(b, name, outputdir):
    """绘制状态转移矩阵热图（带内存管理）"""
    try:
        # 确保输出目录存在
        outputdir = os.path.normpath(outputdir)
        os.makedirs(outputdir, exist_ok=True)
        
        fig = plt.figure(figsize=(15, 15))
        plt.rcParams["font.weight"] = "bold"
        plt.rcParams["axes.labelweight"] = "bold"
        
        ax1 = fig.add_axes([0.1, 0.1, 0.8, 0.8])
        
        # 确保矩阵在CPU上
        matrix = ensure_cpu_data(b.matrix)
        
        # 对数变换以更好地显示概率差异
        log_matrix = np.log10(matrix + 1e-10)  # 添加小值避免log(0)
        
        # 创建热图
        im = ax1.imshow(log_matrix, cmap='Blues', aspect='auto')
        
        # 添加颜色条
        cbar = plt.colorbar(im, ax=ax1)
        cbar.set_label('log10(Transition Probability)', weight='bold')
        
        # 设置刻度
        ax1.set_xticks(np.arange(b.num))
        ax1.set_yticks(np.arange(b.num))
        
        # 设置标签
        state_labels = [f'State {i}' for i in range(b.num)]
        ax1.set_xticklabels(state_labels, rotation=45, ha='right')
        ax1.set_yticklabels(state_labels)
        
        ax1.set_xlabel('To State', weight='bold')
        ax1.set_ylabel('From State', weight='bold')
        ax1.set_title(f'State Transition Matrix - {name}', weight='bold', fontsize=16)
        
        # 添加网格
        ax1.set_xticks(np.arange(b.num + 1) - 0.5, minor=True)
        ax1.set_yticks(np.arange(b.num + 1) - 0.5, minor=True)
        ax1.grid(which='minor', color='gray', linestyle='-', linewidth=0.5)
        
        # 保存图形
        matrix_path = os.path.join(outputdir, f'{name}_transition_matrix.png')
        
        # 使用较低的DPI以节省内存（批处理时可调整）
        dpi = 150 if hasattr(b, 'batch_mode') and b.batch_mode else 300
        fig.savefig(matrix_path, dpi=dpi, bbox_inches='tight')
        
    except Exception as e:
        print(f"Error in plotmatrix: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # 关闭图形
        if 'fig' in locals():
            plt.close(fig)
        plt.close('all')
        
        # 清理内存
        if 'matrix' in locals():
            del matrix
        if 'log_matrix' in locals():
            del log_matrix
        
        gc.collect()
    
    return fig if 'fig' in locals() else None