# safe_gpu_utils.py - 安全的GPU检测和使用工具
import numpy as np

def safe_gpu_check():
    """安全的GPU检测函数，确保不会因为任何原因导致程序崩溃"""
    gpu_info = {
        'available': False,
        'count': 0,
        'name': 'No GPU',
        'memory_gb': 0,
        'compute_capability': (0, 0)
    }
    
    try:
        import cupy as cp
        
        # 尝试获取GPU数量
        try:
            gpu_count = cp.cuda.runtime.getDeviceCount()
            gpu_info['count'] = gpu_count
            
            if gpu_count > 0:
                gpu_info['available'] = True
                
                # 尝试获取GPU属性
                try:
                    # 方法1：使用runtime API
                    props = cp.cuda.runtime.getDeviceProperties(0)
                    
                    # 安全获取名称
                    gpu_info['name'] = safe_get_gpu_name(props)
                    
                    # 安全获取内存
                    gpu_info['memory_gb'] = safe_get_gpu_memory(props)
                    
                    # 安全获取计算能力
                    gpu_info['compute_capability'] = safe_get_compute_capability(props)
                    
                except:
                    # 方法2：使用Device类
                    try:
                        device = cp.cuda.Device(0)
                        # 尝试从device获取信息
                        gpu_info['name'] = f"GPU {device.id}"
                    except:
                        pass
        except:
            # CuPy可用但无法检测GPU
            pass
            
    except ImportError:
        # CuPy不可用
        pass
    except Exception:
        # 其他未知错误
        pass
    
    return gpu_info

def safe_get_gpu_name(props):
    """安全获取GPU名称"""
    try:
        # 尝试各种可能的访问方式
        name_raw = None
        
        # 方式1：字典访问
        if isinstance(props, dict) and 'name' in props:
            name_raw = props['name']
        # 方式2：属性访问
        elif hasattr(props, 'name'):
            name_raw = props.name
        # 方式3：特殊属性
        elif hasattr(props, 'deviceName'):
            name_raw = props.deviceName
        
        if name_raw is None:
            return "Unknown GPU"
        
        # 处理不同的数据类型
        if isinstance(name_raw, bytes):
            # 字节串，需要解码
            name = name_raw.decode('utf-8', errors='replace')
        elif isinstance(name_raw, (list, tuple)) and len(name_raw) > 0:
            # 可能是字符数组
            if isinstance(name_raw[0], int):
                # 整数数组，可能是ASCII码
                name = ''.join(chr(c) for c in name_raw if c != 0)
            else:
                name = str(name_raw)
        else:
            # 其他类型，直接转字符串
            name = str(name_raw)
        
        # 清理特殊字符
        name = ''.join(c for c in name if c.isprintable())
        
        # 如果名称为空，返回默认值
        return name if name.strip() else "Unknown GPU"
        
    except:
        return "Unknown GPU"

def safe_get_gpu_memory(props):
    """安全获取GPU内存（GB）"""
    try:
        memory_bytes = None
        
        # 尝试各种可能的属性名
        for attr in ['totalGlobalMem', 'total_memory', 'totalMemory']:
            if isinstance(props, dict) and attr in props:
                memory_bytes = props[attr]
                break
            elif hasattr(props, attr):
                memory_bytes = getattr(props, attr)
                break
        
        if memory_bytes is not None:
            return float(memory_bytes) / (1024**3)
        
        return 0.0
    except:
        return 0.0

def safe_get_compute_capability(props):
    """安全获取计算能力"""
    try:
        major = minor = 0
        
        # 字典方式
        if isinstance(props, dict):
            major = props.get('major', 0)
            minor = props.get('minor', 0)
        # 属性方式
        elif hasattr(props, 'major') and hasattr(props, 'minor'):
            major = props.major
            minor = props.minor
        # 组合属性
        elif hasattr(props, 'computeCapability'):
            cc = props.computeCapability
            if isinstance(cc, (list, tuple)) and len(cc) >= 2:
                major, minor = cc[0], cc[1]
        
        return (int(major), int(minor))
    except:
        return (0, 0)

def print_gpu_info(logger=None):
    """打印GPU信息（使用安全的检测方法）"""
    gpu_info = safe_gpu_check()
    
    # 选择输出方法
    output_func = logger.info if logger else print
    
    if gpu_info['available']:
        output_func(f"GPU detected: {gpu_info['name']}")
        if gpu_info['memory_gb'] > 0:
            output_func(f"GPU memory: {gpu_info['memory_gb']:.1f} GB")
        if gpu_info['compute_capability'][0] > 0:
            output_func(f"Compute capability: {gpu_info['compute_capability'][0]}.{gpu_info['compute_capability'][1]}")
    else:
        output_func("No GPU detected, using CPU")
    
    return gpu_info['available']

# 测试函数
if __name__ == '__main__':
    print("Testing safe GPU detection...")
    gpu_info = safe_gpu_check()
    print(f"GPU info: {gpu_info}")
    print("\nUsing print_gpu_info:")
    print_gpu_info()