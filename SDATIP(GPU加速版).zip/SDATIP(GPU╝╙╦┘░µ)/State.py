# State.py - GPU accelerated version with memory management
import numpy as np
import cupy as cp
import sympy
from decimal import Decimal, getcontext
import gc

# 设置高精度计算
getcontext().prec = 300

class State():
    def __init__(self, name, use_gpu=True):
        self.name = name
        self.num = 0
        self.downthreshold = []
        self.upthreshold = []
        self.sample = []
        self.chances = []
        self.samplength = []
        self.xsquare = []
        self.pmi = []
        self.Apeak = []
        self.combo = []
        self.arrivaltimestamp = []
        self.multiplesolution = 1
        self.use_gpu = use_gpu and cp.cuda.is_available()
        self.xp = cp if self.use_gpu else np
    
    def __del__(self):
        """析构函数 - 清理内存"""
        self.clear_memory()
    
    def _to_gpu(self, data):
        """将数据移到GPU"""
        if self.use_gpu and not isinstance(data, cp.ndarray):
            return cp.asarray(data)
        return data
    
    def _to_cpu(self, data):
        """将数据移到CPU"""
        if isinstance(data, cp.ndarray):
            return cp.asnumpy(data)
        return data
    
    def clear_memory(self):
        """清理大型数组以释放内存"""
        # 清理矩阵
        if hasattr(self, 'matrix'):
            self.matrix = None
        
        # 清理样本数据
        if hasattr(self, 'sample'):
            self.sample = []
        
        # 清理时间概率
        if hasattr(self, 'timeprob'):
            self.timeprob = None
        
        # 清理特征向量
        if hasattr(self, 'featurevector'):
            self.featurevector = None
        
        # GPU内存清理
        if self.use_gpu:
            try:
                mempool = cp.get_default_memory_pool()
                pinned_mempool = cp.get_default_pinned_memory_pool()
                mempool.free_all_blocks()
                pinned_mempool.free_all_blocks()
            except:
                pass
        
        # 强制垃圾回收
        gc.collect()
    
    def addstate(self, downthreshold, upthreshold, noisesample, chances, pmi, Apeak, arrivaltime):
        """添加单个状态"""
        self.num = self.num + 1
        self.combo.append(1)
        self.downthreshold.append(downthreshold)
        self.upthreshold.append(upthreshold)
        self.sample.append(noisesample)
        self.chances.append(chances)
        self.samplength.append(len(noisesample))
        
        # GPU加速的平方和计算
        noisesample_gpu = self._to_gpu(noisesample)
        xsquare = float(self.xp.sum(noisesample_gpu ** 2))
        self.xsquare.append(xsquare)
        
        self.pmi.append(pmi)
        self.Apeak.append(Apeak)
        self.arrivaltimestamp.append(arrivaltime)
    
    def addcombo(self, combonum, downthreshold, upthreshold, noisesample, chances, pmi, Apeak, arrivaltime):
        """添加组合状态"""
        self.num = self.num + 1
        self.combo.append(combonum)
        self.downthreshold.append(downthreshold)
        self.upthreshold.append(upthreshold)
        self.sample.append(noisesample)
        self.chances.append(chances)
        
        samplength = []
        xsquare = []
        for i in range(combonum):
            samplength.append(len(noisesample[i]))
            # GPU加速的平方和计算
            noisesample_gpu = self._to_gpu(noisesample[i])
            xsquare.append(float(self.xp.sum(noisesample_gpu ** 2)))
        
        self.samplength.append(samplength)
        self.xsquare.append(xsquare)
        self.pmi.append(pmi)
        self.Apeak.append(Apeak)
        self.arrivaltimestamp.append(arrivaltime)
    
    def markovmatrix(self):
        """GPU加速的马尔可夫矩阵计算"""
        # 初始化矩阵
        self.matrix = self.xp.zeros([self.num, self.num])
        
        for i in range(self.num):
            p12 = []
            
            if self.combo[i] == 1:
                # 检查是否与前一个状态相同
                if (i > 0 and self.samplength[i] == self.samplength[i-1] and 
                    np.array_equal(self.sample[i], self.sample[i-1])):
                    self.matrix[i] = self.matrix[i-1]
                    continue
                
                bestsigma = np.sqrt(self.xsquare[i] / self.samplength[i])
                
                # 批量计算所有转移概率
                for j in range(self.num):
                    p1 = sympy.erfc(self.downthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                    p2 = sympy.erfc(self.upthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                    p12_val = sympy.exp(-self.chances[i][0] * p2).evalf(300) - \
                               sympy.exp(-self.chances[i][0] * p1).evalf(300)
                    p12.append(float(p12_val))
            else:
                # 组合状态的处理
                for j in range(self.num):
                    p12combo = 0
                    for k in range(self.combo[i]):
                        bestsigma = np.sqrt(self.xsquare[i][k] / self.samplength[i][k])
                        p1 = sympy.erfc(self.downthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                        p2 = sympy.erfc(self.upthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                        p12combo_val = sympy.exp(-self.chances[i][0] * p2).evalf(300) - \
                                       sympy.exp(-self.chances[i][0] * p1).evalf(300)
                        p12combo = p12combo + float(p12combo_val) / self.combo[i]
                    p12.append(p12combo)
            
            # 归一化
            p12_array = self._to_gpu(np.array(p12))
            self.matrix[i] = p12_array / self.xp.sum(p12_array)
        
        # GPU加速的特征值分解
        if self.use_gpu:
            eigenvalue, featurevector = cp.linalg.eigh(self.matrix.T)
            eigenvalue = self._to_cpu(eigenvalue)
            featurevector = self._to_cpu(featurevector)
        else:
            eigenvalue, featurevector = np.linalg.eig(self.matrix.T)
        
        # 保存特征向量供后续使用
        self.featurevector = featurevector
        
        # 处理特征值
        bigeigvalue = np.sort(np.real(eigenvalue))[-5:]
        self.bigeig = np.around(bigeigvalue[::-1], 3)
        eigindex = np.where(np.real(eigenvalue) > 0.98)[0]
        self.eigvalue = eigenvalue[eigindex]
        
        # 处理不同数量的特征值情况
        if len(eigindex) == 1:
            eig = eigindex[0]
            timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
            timeprob = np.array(timeprob).flatten()
            self.timeprob = [abs(timeprob)]
            return self.timeprob, 1
        
        elif len(eigindex) == 2:
            likesignid = []
            likesignprob = []
            alpha = np.zeros([2, self.num])
            
            for i in range(2):
                eig = eigindex[i]
                timeprob = np.real(abs(featurevector[:, eig]) / np.sum(abs(featurevector[:, eig])))
                alpha[i] = np.array(timeprob).flatten()
                timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
                timeprob = np.array(timeprob).flatten()
                
                if np.sum(timeprob) / np.sum(abs(timeprob)) > 0.999:
                    likesignid.append(i)
                    likesignprob.append(timeprob)
            
            # 搜索最佳参数
            leftrange = -50
            rightrange = 50
            k = np.linspace(leftrange, rightrange, 1 + int(np.round((rightrange - leftrange) / 0.001)))
            bestfit = np.zeros(len(k))
            bestk0s = np.zeros(len(k))
            
            # GPU加速的参数搜索
            alpha_gpu = self._to_gpu(alpha)
            
            for i in range(len(k)):
                k0p = k[i]
                k1p = 1 - k[i]
                probp = k0p * alpha[0] + k1p * alpha[1]
                k0sco = k0p * np.dot(alpha[0], alpha[0]) + k1p * np.dot(alpha[0], alpha[1])
                k1sco = k1p * np.dot(alpha[1], alpha[1]) + k0p * np.dot(alpha[0], alpha[1])
                k0s = -1 * k1sco / (k0sco - k1sco)
                
                # 正交性搜索
                k0srange = np.linspace(k0s - 1, k0s + 1, 401)
                ortho = np.zeros(len(k0srange))
                
                for j in range(len(k0srange)):
                    k0s_j = k0srange[j]
                    k1s_j = 1 - k0s_j
                    probs = k0s_j * alpha[0] + k1s_j * alpha[1]
                    ortho[j] = np.dot(abs(probp), abs(probs))
                
                bestfit[i] = np.min(ortho)
                k0sid = np.where(ortho == np.min(ortho))[0]
                bestk0s[i] = k0srange[k0sid[0]]
            
            # 找到最佳参数对
            bestpair = np.where(bestfit == np.min(bestfit))[0][0]
            k0p = k[bestpair]
            k1p = 1 - k0p
            k0s = bestk0s[bestpair]
            k1s = 1 - k0s
            
            probp = k0p * alpha[0] + k1p * alpha[1]
            probs = k0s * alpha[0] + k1s * alpha[1]
            
            solution = [abs(probp), abs(probs)]
            self.timeprob = solution
            return self.timeprob, 2
        
        elif len(eigindex) == 3:
            self.timeprob = []
            for i in range(len(eigindex)):
                eig = eigindex[i]
                timeprob = np.real(abs(featurevector[:, eig]) / np.sum(abs(featurevector[:, eig])))
                timeprob = np.array(timeprob).flatten()
                self.timeprob.append(abs(timeprob))
            return self.timeprob, 3
        
        else:
            # 默认返回第一个
            self.timeprob = [[1.0 / self.num] * self.num]
            return self.timeprob, 1
    
    def ampprobcalculate(self):
        """GPU加速的振幅概率计算"""
        print('Calculating amplitude probability...')
        self.ampprob_up = []
        self.bestsigma = []
        
        for i in range(self.num):
            if self.combo[i] == 1:
                bestsigma = np.sqrt(self.xsquare[i] / self.samplength[i])
                self.bestsigma.append(bestsigma)
                
                # 高精度计算
                p = 0.5 + 0.5 * sympy.erf(self.Apeak[i][0] / sympy.sqrt(2) / bestsigma).evalf(100)
                self.ampprob_up.append(float(p))
            else:
                ampprob_up = []
                sigma = []
                
                for j in range(self.combo[i]):
                    bestsigma = np.sqrt(self.xsquare[i][j] / self.samplength[i][j])
                    p = 0.5 + 0.5 * sympy.erf(self.Apeak[i][j] / sympy.sqrt(2) / bestsigma).evalf(100)
                    ampprob_up.append(float(p))
                    sigma.append(bestsigma)
                
                self.ampprob_up.append(sum(ampprob_up) / len(ampprob_up))
                self.bestsigma.append(sigma)
            
            if self.ampprob_up[i] > 1:
                self.ampprob_up[i] = 1
        
        return np.array(self.ampprob_up)
    
    def estimation(self, qualifiedid):
        """估计参数"""
        # 确保timeprob是numpy数组
        timeprob = np.array(self.timeprob[qualifiedid])
        
        # GPU加速的向量运算
        timeprob_gpu = self._to_gpu(timeprob)
        ampprob_gpu = self._to_gpu(self.ampprob_up)
        
        self.polarityestimation = float(self.xp.sum(timeprob_gpu * ampprob_gpu))
        
        # 处理未知极性
        unknownindex = np.where(np.array(self.Apeak) == 0)[0]
        knownindex = np.setdiff1d(np.arange(0, self.num), unknownindex)
        
        # 使用numpy数组索引
        if len(unknownindex) > 0:
            self.polarityunknown = float(np.sum(timeprob[unknownindex]))
        else:
            self.polarityunknown = 0.0
            
        if len(knownindex) > 0:
            self.polarityup = float(np.sum(timeprob[knownindex] * np.array(self.ampprob_up)[knownindex]))
        else:
            self.polarityup = 0.0
            
        self.polaritydown = 1 - self.polarityup - self.polarityunknown
        
        # 估计其他参数
        Apeakestimate = np.zeros(self.num)
        arrivalestimate = np.zeros(self.num)
        sigmaestimate = np.zeros(self.num)
        
        for i in range(self.num):
            Apeakestimate[i] = np.sum(self.Apeak[i]) / self.combo[i]
            arrivalestimate[i] = np.sum(self.arrivaltimestamp[i]) / self.combo[i]
            sigmaestimate[i] = np.sum(self.bestsigma[i]) / self.combo[i]
        
        self.Apeakestimate = float(np.sum(timeprob * Apeakestimate))
        self.arrivalestimate = float(np.sum(timeprob * arrivalestimate))
        self.sigmaestimate = float(np.sum(timeprob * sigmaestimate))
    
    def timeprobinterpolate(self):
        """时间概率插值（待实现）"""
        print('Coming soon...')
    
    def getstateinform(self, stateid):
        """获取状态信息"""
        if stateid >= self.num:
            print('Wrong state ID')
            return -1, -1, -1, -1, -1
        else:
            return (self.combo[stateid], self.downthreshold[stateid], 
                   self.upthreshold[stateid], self.sample[stateid], 
                   self.pmi[stateid], self.Apeak[stateid])
    
    def getstateprob(self, qualifiedid, stateid):
        """获取状态概率"""
        if stateid >= self.num:
            print('Wrong state ID')
            return -1, -1
        else:
            return self.timeprob[qualifiedid][stateid], self.ampprob_up[stateid]
    
    def save_results(self, filename):
        """保存结果到文件（用于批处理）"""
        try:
            # 确保所有数据都在CPU上
            results = {
                'num_states': self.num,
                'downthreshold': self.downthreshold,
                'upthreshold': self.upthreshold,
                'Apeak': self.Apeak,
                'timeprob': [self._to_cpu(tp) if isinstance(tp, cp.ndarray) else tp 
                           for tp in self.timeprob] if hasattr(self, 'timeprob') else [],
                'ampprob_up': self._to_cpu(self.ampprob_up) if hasattr(self, 'ampprob_up') else [],
                'eigvalue': self._to_cpu(self.eigvalue) if hasattr(self, 'eigvalue') else [],
                'bigeig': self._to_cpu(self.bigeig) if hasattr(self, 'bigeig') else []
            }
            
            # 可以保存为.npz或.mat格式
            if filename.endswith('.npz'):
                np.savez(filename, **results)
            elif filename.endswith('.mat'):
                import scipy.io as scio
                scio.savemat(filename, results)
            
            return True
        except Exception as e:
            print(f"Error saving results: {e}")
            return False