# pmi.py - GPU accelerated version
import numpy as np
import cupy as cp
from functools import reduce

# 动态选择计算后端
def get_array_module(arr):
    """根据输入数组类型返回对应的模块（numpy或cupy）"""
    return cp.get_array_module(arr)

def Entropy(ampen2):
    """计算二进制序列的信息熵"""
    xp = get_array_module(ampen2)
    
    zeronum = int(xp.sum(ampen2 == 0))
    onenum = int(xp.sum(ampen2 == 1))
    
    if zeronum == 0 or onenum == 0:
        return 0
    
    length2 = len(ampen2)
    pzero = zeronum / length2
    pone = onenum / length2
    en = xp.log2(pzero) * pzero + xp.log2(pone) * pone
    
    # 如果是GPU数组，转换为标量
    if xp == cp:
        return float(-en)
    return -en

def pmi(ampbi, t):
    """计算点互信息"""
    xp = get_array_module(ampbi)
    lengthall = len(ampbi)
    
    # GPU加速的计数操作
    zeronum0 = int(xp.sum(ampbi[0:t] == 0))
    zeronum1 = int(xp.sum(ampbi[0:t] == 1))
    onenum0 = int(xp.sum(ampbi[t:] == 0))
    onenum1 = int(xp.sum(ampbi[t:] == 1))
    
    pmi = xp.zeros([2, 2])
    npmi = xp.zeros([2, 2])
    
    # 计算PMI矩阵
    if zeronum0 == 0:
        pmi[0, 0] = 0
        npmi[0, 0] = -1
    else:
        pmi[0, 0] = zeronum0 / lengthall * xp.log2(
            zeronum0 * lengthall / (zeronum0 + zeronum1) / (zeronum0 + onenum0)
        )
        npmi[0, 0] = (-1) * xp.log2(
            zeronum0 * lengthall / (zeronum0 + zeronum1) / (zeronum0 + onenum0)
        ) / xp.log2(zeronum0 / lengthall)
    
    if zeronum1 == 0:
        pmi[0, 1] = 0
        npmi[0, 1] = -1
    else:
        pmi[0, 1] = zeronum1 / lengthall * xp.log2(
            zeronum1 * lengthall / (zeronum0 + zeronum1) / (zeronum1 + onenum1)
        )
        npmi[0, 1] = (-1) * xp.log2(
            zeronum1 * lengthall / (zeronum0 + zeronum1) / (zeronum1 + onenum1)
        ) / xp.log2(zeronum1 / lengthall)
    
    if onenum0 == 0:
        pmi[1, 0] = 0
        npmi[1, 0] = -1
    else:
        pmi[1, 0] = onenum0 / lengthall * xp.log2(
            onenum0 * lengthall / (onenum0 + onenum1) / (zeronum0 + onenum0)
        )
        npmi[1, 0] = (-1) * xp.log2(
            onenum0 * lengthall / (onenum0 + onenum1) / (zeronum0 + onenum0)
        ) / xp.log2(onenum0 / lengthall)
    
    if onenum1 == 0:
        pmi[1, 1] = 0
        npmi[1, 1] = -1
    else:
        pmi[1, 1] = onenum1 / lengthall * xp.log2(
            onenum1 * lengthall / (onenum0 + onenum1) / (zeronum1 + onenum1)
        )
        npmi[1, 1] = (-1) * xp.log2(
            onenum1 * lengthall / (onenum0 + onenum1) / (zeronum1 + onenum1)
        ) / xp.log2(onenum1 / lengthall)
    
    mivalue = float(xp.sum(pmi))
    qmivalue = float(pmi[0, 0] - pmi[0, 1] - pmi[1, 0] + pmi[1, 1])
    npmivalue = float(npmi[0, 0] - npmi[0, 1] - npmi[1, 0] + npmi[1, 1])
    enpmivalue = float(
        npmi[0, 0] * zeronum0 / lengthall - npmi[0, 1] * zeronum1 / lengthall -
        npmi[1, 0] * onenum0 / lengthall + npmi[1, 1] * onenum1 / lengthall
    )
    
    return mivalue, enpmivalue

def maxpmi(ampbi, n):
    """寻找最大PMI的分割点"""
    xp = get_array_module(ampbi)
    
    zeronum = int(xp.sum(ampbi == 0))
    onenum = int(xp.sum(ampbi == 1))
    
    if zeronum == 0 or onenum == 0:
        return -1, -1, -1
    
    if n != -1:
        mi_val, pmi_val = pmi(ampbi, n)
        return mi_val, pmi_val, n
    else:
        # GPU加速的向量化操作
        result = xp.zeros([len(ampbi) - 1, 2])
        
        # 找到所有可能的分割点
        diff = ampbi[1:] - ampbi[0:-1]
        readyindex = xp.where(diff == 1)[0]
        
        if xp == cp:
            readyindex_cpu = readyindex.get()
        else:
            readyindex_cpu = readyindex
        
        # 批量计算PMI
        for i in range(len(readyindex_cpu)):
            idx = int(readyindex_cpu[i])
            result[idx] = pmi(ampbi, idx + 1)
        
        # 找到最大值
        max_idx = int(xp.argmax(result[:, 1]))
        
        if xp == cp:
            return float(result[max_idx, 0]), float(result[max_idx, 1]), max_idx + 1
        else:
            return result[max_idx, 0], result[max_idx, 1], max_idx + 1

def calculategeneral(xsquare, n):
    """计算通用概率分布"""
    if n == 3:
        return 1 / xsquare
    if n == 2:
        return np.sqrt(np.pi / 2 / xsquare)
    if np.mod(n, 2) == 1:
        m = (n - 3) / 2
        lt = range(2, n - 1, 2)
        return reduce(lambda x, y: x * y, lt) * (1 / xsquare) ** (m + 1)
    if np.mod(n, 2) == 0:
        m = (n - 2) / 2
        lt = range(1, n - 2, 2)
        return reduce(lambda x, y: x * y, lt) * np.sqrt(np.pi / 2 / xsquare) * (1 / xsquare) ** m