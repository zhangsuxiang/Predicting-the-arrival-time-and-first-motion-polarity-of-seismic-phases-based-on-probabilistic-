#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
专门测试psutil问题
"""

import os
import sys
import psutil
import locale

# 显示系统信息
print("=== System Information ===")
print(f"Python version: {sys.version}")
print(f"psutil version: {psutil.__version__}")
print(f"OS: {sys.platform}")
print(f"Default encoding: {sys.getdefaultencoding()}")
print(f"File system encoding: {sys.getfilesystemencoding()}")
print(f"Locale: {locale.getdefaultlocale()}")

# 测试当前工作目录
print(f"\nCurrent working directory: {os.getcwd()}")
print(f"Directory contains non-ASCII: {'是' if any(ord(c) > 127 for c in os.getcwd()) else '否'}")

# 导入配置
import batch_config as config

# 测试不同的路径格式
print("\n=== Testing Path Formats ===")
paths_to_test = [
    (".", "Current directory"),
    (os.getcwd(), "Current directory (absolute)"),
    ("C:\\", "C drive root"),
    (config.OUTPUT_DIR, "Config OUTPUT_DIR"),
    (os.path.abspath(config.OUTPUT_DIR), "Config OUTPUT_DIR (absolute)"),
]

# 添加一些可能有问题的路径
if os.path.exists("C:\\Users"):
    paths_to_test.append(("C:\\Users", "Users directory"))

for path, description in paths_to_test:
    print(f"\nTesting: {description}")
    print(f"  Path: '{path}'")
    print(f"  Type: {type(path)}")
    print(f"  Repr: {repr(path)}")
    
    try:
        # 确保路径存在（对于相对路径）
        if path in ['.', config.OUTPUT_DIR]:
            os.makedirs(path, exist_ok=True)
        
        # 测试路径是否存在
        exists = os.path.exists(path)
        print(f"  Exists: {exists}")
        
        if exists:
            # 尝试获取磁盘使用情况
            usage = psutil.disk_usage(path)
            print(f"  ✓ Disk usage: {usage.percent:.1f}%")
        else:
            print(f"  ✗ Path does not exist")
            
    except Exception as e:
        print(f"  ✗ Error: {e}")
        print(f"  Error type: {type(e).__name__}")
        
        # 尝试打印更多错误信息
        if hasattr(e, 'args'):
            print(f"  Error args: {e.args}")
        
        # 检查是否是编码问题
        try:
            # 尝试不同的编码
            if isinstance(path, str):
                path_bytes = path.encode('utf-8')
                print(f"  Path as UTF-8 bytes: {path_bytes}")
                
                # 尝试使用不同的方法
                print("  Trying alternative methods...")
                
                # 方法1：使用os.path.realpath
                try:
                    real_path = os.path.realpath(path)
                    print(f"  Real path: {real_path}")
                    usage = psutil.disk_usage(real_path)
                    print(f"  ✓ Success with realpath: {usage.percent:.1f}%")
                except Exception as e2:
                    print(f"  ✗ Realpath also failed: {e2}")
                
                # 方法2：使用os.path.normpath
                try:
                    norm_path = os.path.normpath(path)
                    print(f"  Normalized path: {norm_path}")
                    usage = psutil.disk_usage(norm_path)
                    print(f"  ✓ Success with normpath: {usage.percent:.1f}%")
                except Exception as e3:
                    print(f"  ✗ Normpath also failed: {e3}")
                    
        except Exception as encode_error:
            print(f"  Encoding check failed: {encode_error}")

# 测试内存和CPU信息（这些通常不会有问题）
print("\n=== Testing Other psutil Functions ===")
try:
    memory = psutil.virtual_memory()
    print(f"✓ Memory: {memory.percent:.1f}% used")
except Exception as e:
    print(f"✗ Memory check failed: {e}")

try:
    cpu_percent = psutil.cpu_percent(interval=0.1)
    print(f"✓ CPU: {cpu_percent:.1f}% used")
except Exception as e:
    print(f"✗ CPU check failed: {e}")

# 测试所有磁盘分区
print("\n=== Testing All Disk Partitions ===")
try:
    partitions = psutil.disk_partitions()
    for partition in partitions:
        print(f"\nPartition: {partition.device}")
        print(f"  Mountpoint: {partition.mountpoint}")
        print(f"  Fstype: {partition.fstype}")
        
        try:
            usage = psutil.disk_usage(partition.mountpoint)
            print(f"  ✓ Usage: {usage.percent:.1f}%")
        except Exception as e:
            print(f"  ✗ Error getting usage: {e}")
except Exception as e:
    print(f"✗ Error getting partitions: {e}")

print("\n=== Test completed ===")