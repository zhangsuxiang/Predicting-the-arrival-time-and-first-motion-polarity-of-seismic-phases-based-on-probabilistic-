import Waveform
import State
import pmi

# GPU availability check
import cupy as cp

def check_gpu():
    """检查GPU是否可用"""
    try:
        gpu_count = cp.cuda.runtime.getDeviceCount()
        if gpu_count > 0:
            try:
                device_props = cp.cuda.runtime.getDeviceProperties(0)
                # 修复：正确处理GPU名称
                # CuPy可能返回不同格式的属性
                try:
                    if hasattr(device_props, 'name'):
                        # 属性访问方式
                        gpu_name_raw = device_props.name
                    elif isinstance(device_props, dict) and 'name' in device_props:
                        # 字典访问方式
                        gpu_name_raw = device_props['name']
                    else:
                        gpu_name_raw = "Unknown"
                    
                    # 处理字节串或字符串
                    if isinstance(gpu_name_raw, bytes):
                        gpu_name = gpu_name_raw.decode('utf-8', errors='replace')
                    else:
                        gpu_name = str(gpu_name_raw)
                except:
                    gpu_name = "Unknown GPU"
                
                # 清理GPU名称中的特殊字符
                gpu_name = ''.join(c for c in gpu_name if c.isprintable())
                
                print(f"GPU detected: {gpu_name}")
                return True
            except Exception as e:
                print(f"GPU property detection failed: {e}")
                return False
        else:
            print("No GPU detected, falling back to CPU")
            return False
    except Exception as e:
        print(f"GPU detection failed: {e}")
        print("Falling back to CPU")
        return False

# 延迟GPU检查，避免模块导入时的问题
GPU_AVAILABLE = False

def initialize_gpu():
    """初始化GPU检查"""
    global GPU_AVAILABLE
    GPU_AVAILABLE = check_gpu()
    return GPU_AVAILABLE