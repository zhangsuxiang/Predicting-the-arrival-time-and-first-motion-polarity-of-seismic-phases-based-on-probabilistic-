# plotresult.py - Windows compatible version with memory management
import numpy as np
import matplotlib
# Windows下注释掉Agg后端，使用默认后端
# matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os
import gc

def ensure_cpu_data(data):
    """确保数据在CPU上（处理可能的GPU数据）"""
    try:
        import cupy as cp
        if isinstance(data, cp.ndarray):
            return cp.asnumpy(data)
    except:
        pass
    return data

def plotprob(a, b, qualifiedid, name, outputdir):
    """绘制概率分布图（Windows兼容版本，带内存管理）"""
    try:
        # 确保输出目录存在
        outputdir = os.path.normpath(outputdir)
        os.makedirs(outputdir, exist_ok=True)
        
        # 创建图形
        fig = plt.figure(figsize=(25, 9))
        plt.rcParams["font.weight"] = "bold"
        plt.rcParams["axes.labelweight"] = "bold"
        
        # 确保数据在CPU上
        timeprob = ensure_cpu_data(b.timeprob[qualifiedid])
        longtimestamp = ensure_cpu_data(a.longtimestamp)
        denselongdata = ensure_cpu_data(a.denselongdata)
        timestamp = ensure_cpu_data(a.timestamp)
        densetimestamp = ensure_cpu_data(a.densetimestamp)
        
        # 主图
        ax1 = fig.add_axes([0.4, 0.33, 0.55, 0.6])
        ax1.plot(longtimestamp, denselongdata,
                 linewidth=2.5, color='k', linestyle='-')
        ax1.plot(longtimestamp, abs(denselongdata),
                 linewidth=2.5, color='k', linestyle=':', alpha=0.9)
        
        # 调整阈值
        b.upthreshold[-1] = b.upthreshold[-2] * 1.5
        
        # 准备绘图所需数据
        colori = np.zeros([b.num, 3])
        prob1 = timeprob / (np.array(b.upthreshold) - np.array(b.downthreshold))
        alphacoefficient = (0.75 - 0.03) / np.max(prob1)
        downt = np.zeros(b.num)
        upt = np.zeros(b.num)
        
        # 确保cut数据在CPU上
        cut = ensure_cpu_data(a.cut)
        
        for i in range(b.num):
            if b.Apeak[i][0] > 0:
                colori[i, :] = [1, 0, 0]
            elif b.Apeak[i][0] < 0:
                colori[i, :] = [0, 1, 0]
            
            cut_idx = int(cut[i])
            
            if abs(b.Apeak[i][0]) > 0:
                dt = longtimestamp[cut_idx + 1] - longtimestamp[cut_idx]
                da = denselongdata[cut_idx + 1] - denselongdata[cut_idx]
                downt[i] = dt / da * (b.downthreshold[i] - abs(denselongdata[cut_idx])) + longtimestamp[cut_idx]
                upt[i] = dt / da * (b.upthreshold[i] - abs(denselongdata[cut_idx])) + longtimestamp[cut_idx]
                
                # 画竖线和横线
                for x, thr in [(downt[i], b.downthreshold[i]), (upt[i], b.upthreshold[i])]:
                    ax1.plot([x, x], [thr, -b.upthreshold[-1]],
                             linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                    ax1.plot([0, x], [thr, thr],
                             linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                
                # 填充区域
                ax1.fill_between(
                    [0, downt[i], upt[i]],
                    [b.downthreshold[i]] * 3,
                    [b.upthreshold[i]] * 3,
                    color=colori[i, :],
                    alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
                )
                ax1.fill_betweenx(
                    [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                    [downt[i]] * 3,
                    [upt[i]] * 3,
                    color=colori[i, :],
                    alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
                )
            else:
                # Apeak == 0 时的处理
                downt[i] = longtimestamp[-1]
                upt[i] = longtimestamp[-1] + 0.1 * timestamp[-1]
                for x, thr in [(downt[i], b.downthreshold[i]), (upt[i], b.upthreshold[i])]:
                    ax1.plot([x, x], [thr, -b.upthreshold[-1]],
                             linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                    ax1.plot([0, x], [thr, thr],
                             linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                ax1.fill_between(
                    [0, downt[i], upt[i]],
                    [b.downthreshold[i]] * 3,
                    [b.upthreshold[i]] * 3,
                    color=colori[i, :],
                    alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
                )
                ax1.fill_betweenx(
                    [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                    [downt[i]] * 3,
                    [upt[i]] * 3,
                    color=colori[i, :],
                    alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
                )
        
        # 坐标轴范围与刻度
        ax1.set(xlim=(0, np.max(densetimestamp) + 0.1 * timestamp[-1]),
                ylim=(-b.upthreshold[-2], b.upthreshold[-1]))
        ax1.tick_params(direction='out', size=20)
        
        ax1.set_yticks([-b.upthreshold[-2], 0, b.upthreshold[-1]])
        ax1.set_yticklabels(
            ['%.2f' % (-b.upthreshold[-2]), '0.00', '%.2f' % b.upthreshold[-1]],
            fontweight='bold'
        )
        
        ax1.set_xticks(np.linspace(0, timestamp[-1], 5))
        ax1.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, timestamp[-1], 5)],
            fontweight='bold'
        )
        
        for spine in ax1.spines.values():
            spine.set_linewidth(2)
        
        # 第二个子图：概率条形图
        ax2 = fig.add_axes([
            0.1,
            0.93 - 0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1],
            0.25,
            0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1]
        ])
        ax2.invert_xaxis()
        for i in range(b.num):
            ax2.fill_betweenx(
                [b.downthreshold[i], b.upthreshold[i]],
                0, prob1[i],
                color=colori[i, :],
                alpha=1
            )
            ax2.plot([0, prob1[i]], [b.upthreshold[i]] * 2,
                     linewidth=0.001, color='k', linestyle='--')
            ax2.plot([0, prob1[i]], [b.downthreshold[i]] * 2,
                     linewidth=0.001, color='k', linestyle='--')
        
        ax2.set(ylim=(0, b.upthreshold[-1]))
        ax2.set_xticks(np.linspace(0, np.max(prob1), 5))
        ax2.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, np.max(prob1), 5)],
            fontweight='bold'
        )
        ax2.set_yticks(np.linspace(0, b.upthreshold[-1], 5))
        ax2.set_yticklabels(
            ['%.2f' % val for val in np.linspace(0, b.upthreshold[-1], 5)],
            fontweight='bold'
        )
        ax2.tick_params(direction='out', size=20)
        ax2.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
        ax2.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
        for spine in ax2.spines.values():
            spine.set_linewidth(2)
        
        # 第三个子图：时间概率分布
        ax3 = fig.add_axes([0.4, 0.1, 0.55, 0.15], sharex=ax1)
        for i in range(b.num):
            ax3.plot([downt[i], downt[i]],
                     [0, np.max(prob1) * 1.1],
                     linewidth=0.001, color='k', linestyle='-', alpha=0.3)
            ax3.plot([upt[i], upt[i]],
                     [0, np.max(prob1) * 1.1],
                     linewidth=0.001, color='k', linestyle='-', alpha=0.3)
            ax3.plot([downt[i], upt[i]],
                     [prob1[i]] * 2,
                     linewidth=0.001, color='k', linestyle='-', alpha=0.3)
            ax3.fill_between(
                [downt[i], upt[i]],
                [0, 0],
                [prob1[i]] * 2,
                color=colori[i, :],
                alpha=1
            )
        ax3.plot([b.arrivalestimate] * 2,
                 [0, np.max(prob1) * 1.1],
                 linewidth=2.3, color='k', linestyle=':', alpha=0.9)
        
        ax3.set(ylim=(0, np.max(prob1) * 1.1))
        ax3.set_yticks(np.linspace(0, np.max(prob1), 3))
        ax3.set_yticklabels(
            ['%.2f' % val for val in np.linspace(0, np.max(prob1), 3)],
            fontweight='bold'
        )
        ax3.set_xticks(np.linspace(0, timestamp[-1], 5))
        ax3.set_xticklabels(
            ['%.2f' % val for val in np.linspace(0, timestamp[-1], 5)],
            fontweight='bold'
        )
        ax3.tick_params(direction='out', size=20)
        ax3.set_ylabel('PDF of Time', weight='bold')
        ax3.set_xlabel('Time/s', weight='bold')
        for spine in ax3.spines.values():
            spine.set_linewidth(2)
        
        # 第四个子图：极性统计
        ax4 = fig.add_axes([0.1, 0.13, 0.23, 0.05])
        y = [1, 1, 1]
        width = [float(b.polarityup), float(b.polarityunknown), float(b.polaritydown)]
        leftcoord = [0,
                     float(b.polarityup),
                     float(b.polarityup + b.polarityunknown)]
        colors = [[1, 0, 0], [0.7, 0.7, 0.7], [0, 1, 0]]
        labels = ['Up', 'Unknown', 'Down']
        for i in range(3):
            ax4.barh(y[i], width[i], height=1,
                     left=leftcoord[i], color=colors[i], label=labels[i])
        
        ax4.set_xticks([0.5])
        ax4.set_xticklabels(['0.5'], fontweight='bold')
        ax4.text(0, 2, 'Up:%.1f%%' % (float(b.polarityup) * 100))
        ax4.text(0.85, 2, 'Down:%.1f%%' % (float(b.polaritydown) * 100))
        ax4.set_yticks([])
        ax4.set(xlim=(0, 1), ylim=(0.5, 1.5))
        ax4.plot([0.5, 0.5], [0, 1.5],
                 linewidth=2.5, color='k', linestyle=':', alpha=1)
        ax4.legend(ncol=3, loc='lower center', bbox_to_anchor=(0.5, 1.5))
        for spine in ax4.spines.values():
            spine.set_linewidth(2)
        
        # 添加标题和统计信息
        fig.text(0.21, 0.38, name,
                 {'fontweight': 'bold', 'fontsize': 25},
                 horizontalalignment='center')
        fig.text(0.24, 0.33,
                 r'$\mathbf{A_{peak}}$: %.3f' % b.Apeakestimate,
                 {'fontweight': 'bold', 'fontsize': 15})
        fig.text(0.24, 0.28,
                 r'$\mathbf{\sigma}$: %.3f' % b.sigmaestimate,
                 {'fontweight': 'bold', 'fontsize': 15})
        fig.text(0.1, 0.33,
                 'Arrivaltime: %.3f' % b.arrivalestimate,
                 {'fontweight': 'bold', 'fontsize': 15})
        fig.text(0.1, 0.28,
                 'Polarity Up: %.3f' % b.polarityestimation,
                 {'fontweight': 'bold', 'fontsize': 15})
        fig.text(0.1, 0.23,
                 'Eig value: %s' % b.bigeig)
        
        # 保存图像（Windows路径兼容）
        png_path = os.path.join(outputdir, f'{name}_{qualifiedid}.png')
        pdf_path = os.path.join(outputdir, f'{name}_{qualifiedid}.pdf')
        
        # 使用较低的DPI以节省内存（批处理时可调整）
        dpi = 300 if hasattr(b, 'batch_mode') and b.batch_mode else 1300
        
        fig.savefig(png_path, dpi=dpi)
        # 只在非批处理模式下保存PDF
        if not (hasattr(b, 'batch_mode') and b.batch_mode):
            fig.savefig(pdf_path)
        
    except Exception as e:
        print(f"Error in plotprob: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # 关闭图形以释放内存
        plt.close(fig)
        plt.close('all')  # 确保关闭所有图形
        
        # 清理内存
        if 'fig' in locals():
            del fig
        if 'ax1' in locals():
            del ax1
        if 'ax2' in locals():
            del ax2
        if 'ax3' in locals():
            del ax3
        if 'ax4' in locals():
            del ax4
        
        # 强制垃圾回收
        gc.collect()

def plotprob_batch(a, b, qualifiedid, name, outputdir):
    """批处理优化版本的绘图函数"""
    # 设置批处理模式标志
    b.batch_mode = True
    plotprob(a, b, qualifiedid, name, outputdir)
    b.batch_mode = False