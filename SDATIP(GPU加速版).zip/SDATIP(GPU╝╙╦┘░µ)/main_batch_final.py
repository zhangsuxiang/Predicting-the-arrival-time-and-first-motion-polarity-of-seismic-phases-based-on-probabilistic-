#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
批量地震波形处理主程序 - 安全版本
避开psutil.disk_usage的问题
"""

import os
import sys
import glob
import time
import logging
import traceback
from datetime import datetime
import multiprocessing as mp
from pathlib import Path
import json
import csv

import numpy as np
import obspy
import psutil
import gc

# 尝试导入CuPy
try:
    import cupy as cp
    CUPY_AVAILABLE = True
except ImportError:
    CUPY_AVAILABLE = False
    cp = None

# 导入配置和处理模块
import batch_config as config
from single_batch import solutionset, clear_memory

# 安全的磁盘使用检查函数
def safe_disk_usage(path):
    """安全的磁盘使用检查，如果失败返回None"""
    try:
        # 尝试多种路径格式
        attempts = [
            path,
            os.path.abspath(path),
            os.path.normpath(path),
            os.path.realpath(path)
        ]
        
        for attempt in attempts:
            try:
                if os.path.exists(attempt):
                    return psutil.disk_usage(attempt)
            except:
                continue
        
        # 如果都失败了，尝试使用当前目录
        return psutil.disk_usage(os.getcwd())
        
    except Exception as e:
        # 完全失败，返回None
        print(f"Warning: Could not get disk usage: {e}")
        return None

# 安全的GPU检测函数
def safe_check_gpu():
    """安全的GPU检测，确保不会导致程序崩溃"""
    if not CUPY_AVAILABLE or config.FORCE_CPU:
        return False, "No GPU (CuPy not available or CPU forced)"
    
    try:
        gpu_count = cp.cuda.runtime.getDeviceCount()
        if gpu_count > 0:
            return True, f"{gpu_count} GPU(s) detected"
        else:
            return False, "No GPU detected"
    except Exception as e:
        error_msg = str(e).replace('%', '%%').replace('{', '{{').replace('}', '}}')
        return False, f"GPU detection failed: {error_msg}"

# 设置日志
def setup_logging():
    """设置日志系统"""
    log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
    # 控制台日志
    console_handler = logging.StreamHandler()
    console_handler.setLevel(getattr(logging, config.LOG_LEVEL))
    
    handlers = [console_handler]
    
    # 文件日志
    if config.SAVE_DETAILED_LOG:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_filename = config.LOG_FILENAME.format(timestamp=timestamp)
        # 使用绝对路径
        output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
        log_path = os.path.join(output_dir_abs, log_filename)
        file_handler = logging.FileHandler(log_path, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        handlers.append(file_handler)
    
    logging.basicConfig(
        level=logging.DEBUG,
        format=log_format,
        handlers=handlers
    )
    
    return logging.getLogger(__name__)

class BatchProcessor:
    """批处理器类 - 安全版本"""
    
    def __init__(self, logger):
        self.logger = logger
        self.stats = {
            'total_files': 0,
            'processed': 0,
            'failed': 0,
            'skipped': 0,
            'start_time': None,
            'end_time': None
        }
        self.results = []
        self.failed_files = []
        
    def check_system_resources(self):
        """检查系统资源 - 安全版本"""
        try:
            memory = psutil.virtual_memory()
            
            self.logger.info("System resources:")
            self.logger.info(f"  CPU cores: {mp.cpu_count()}")
            self.logger.info(f"  Memory: {memory.percent:.1f}%% used ({memory.used/1024**3:.1f}/{memory.total/1024**3:.1f} GB)")
            
            # 安全的磁盘检查
            output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
            disk = safe_disk_usage(output_dir_abs)
            if disk:
                self.logger.info(f"  Disk: {disk.percent:.1f}%% used ({disk.free/1024**3:.1f} GB free)")
            else:
                self.logger.info("  Disk: Unable to determine disk usage")
            
            # GPU检查
            gpu_available, gpu_info = safe_check_gpu()
            self.logger.info(f"  GPU: {gpu_info}")
            
            # 如果需要更详细的GPU信息且GPU可用
            if gpu_available and CUPY_AVAILABLE:
                try:
                    gpu_count = cp.cuda.runtime.getDeviceCount()
                    for i in range(min(gpu_count, 4)):
                        try:
                            self.logger.info(f"  GPU {i}: Available")
                            
                            with cp.cuda.Device(i):
                                mem_info = cp.cuda.runtime.memGetInfo()
                                free_gb = mem_info[0] / 1024**3
                                total_gb = mem_info[1] / 1024**3
                                self.logger.info(f"    Memory: {free_gb:.1f}/{total_gb:.1f} GB free")
                        except Exception as e:
                            error_msg = str(e).replace('%', '%%').replace('{', '{{').replace('}', '}}')
                            self.logger.debug(f"    Could not get detailed info for GPU {i}: {error_msg}")
                except Exception as e:
                    error_msg = str(e).replace('%', '%%').replace('{', '{{').replace('}', '}}')
                    self.logger.debug(f"  Could not get detailed GPU information: {error_msg}")
            
            return memory.percent < config.MEMORY_THRESHOLD
            
        except Exception as e:
            error_msg = str(e).replace('%', '%%').replace('{', '{{').replace('}', '}}')
            self.logger.error(f"Error checking system resources: {error_msg}")
            return True  # 继续处理，即使无法检查资源
    
    def validate_sac_file(self, sac_file):
        """验证SAC文件"""
        try:
            # 检查文件大小
            file_size = os.path.getsize(sac_file)
            if file_size < config.FILE_FILTERS['min_size']:
                return False, "File too small"
            if file_size > config.FILE_FILTERS['max_size']:
                return False, "File too large"
            
            # 尝试读取文件
            if config.VALIDATE_SAC:
                st = obspy.read(sac_file, headonly=True)
                if len(st) == 0:
                    return False, "Empty stream"
            
            # 用户自定义过滤器
            if hasattr(config, 'custom_filter'):
                if not config.custom_filter(sac_file):
                    return False, "Custom filter rejected"
            
            return True, "Valid"
            
        except Exception as e:
            return False, str(e).replace('%', '%%')
    
    def process_single_file(self, args):
        """处理单个文件（带重试机制）"""
        sac_file, event_name, output_event_dir = args
        
        for retry in range(config.ERROR_HANDLING['max_retries'] + 1):
            try:
                # 验证文件
                valid, reason = self.validate_sac_file(sac_file)
                if not valid:
                    self.logger.debug(f"Skipping {sac_file}: {reason}")
                    return 'skipped', sac_file, reason
                
                # 生成输出名称
                waveform_name = Path(sac_file).stem
                if hasattr(config, 'custom_naming'):
                    full_name = config.custom_naming(event_name, waveform_name)
                else:
                    full_name = f"{event_name}_{waveform_name}"
                
                # 读取数据
                st = obspy.read(sac_file)
                data = st[0].data
                
                # 处理波形
                self.logger.debug(f"Processing: {sac_file} (attempt {retry + 1})")
                success, result = solutionset(
                    full_name, 
                    data, 
                    output_event_dir,
                    skip_plots=config.SKIP_PLOTS,
                    save_intermediate=config.SAVE_INTERMEDIATE
                )
                
                if success:
                    return 'success', sac_file, result
                else:
                    if retry < config.ERROR_HANDLING['max_retries']:
                        time.sleep(config.ERROR_HANDLING['retry_delay'])
                        continue
                    return 'failed', sac_file, result
                    
            except Exception as e:
                if retry < config.ERROR_HANDLING['max_retries']:
                    error_msg = str(e).replace('%', '%%')
                    self.logger.warning(f"Retry {retry + 1} for {sac_file}: {error_msg}")
                    time.sleep(config.ERROR_HANDLING['retry_delay'])
                    continue
                
                error_msg = str(e).replace('%', '%%')
                self.logger.error(f"Failed processing {sac_file}: {error_msg}")
                self.logger.debug(traceback.format_exc())
                return 'failed', sac_file, error_msg
    
    def process_event(self, event_dir):
        """处理单个事件的所有波形"""
        event_name = os.path.basename(event_dir)
        # 使用绝对路径
        output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
        output_event_dir = os.path.join(output_dir_abs, event_name)
        os.makedirs(output_event_dir, exist_ok=True)
        
        # 获取所有SAC文件
        sac_files = []
        for ext in config.FILE_FILTERS['extensions']:
            sac_files.extend(glob.glob(os.path.join(event_dir, f"*{ext}")))
        sac_files = list(set(sac_files))  # 去重
        
        # 排序
        if config.PROCESS_PRIORITY == 'time':
            sac_files.sort(key=lambda x: os.path.getmtime(x))
        elif config.PROCESS_PRIORITY == 'size':
            sac_files.sort(key=lambda x: os.path.getsize(x))
        else:
            sac_files.sort()
        
        if not sac_files:
            self.logger.warning(f"No SAC files found in {event_dir}")
            return []
        
        self.logger.info(f"Processing event: {event_name} ({len(sac_files)} files)")
        
        # 准备参数
        args_list = [(f, event_name, output_event_dir) for f in sac_files]
        event_results = []
        
        # 分批处理
        for i in range(0, len(args_list), config.BATCH_SIZE):
            batch = args_list[i:i + config.BATCH_SIZE]
            batch_num = i // config.BATCH_SIZE + 1
            total_batches = (len(args_list) + config.BATCH_SIZE - 1) // config.BATCH_SIZE
            
            self.logger.info(f"  Batch {batch_num}/{total_batches} ({len(batch)} files)")
            
            # 检查内存
            if not self.check_system_resources():
                self.logger.warning("Low memory, performing cleanup...")
                clear_memory()
                gc.collect()
            
            # 处理批次
            if config.PARALLEL_STRATEGY == 'sequential':
                # 串行处理
                for args in batch:
                    result = self.process_single_file(args)
                    event_results.append(result)
                    self.update_stats(result[0])
            else:
                # 并行处理
                with mp.Pool(processes=min(config.MAX_WORKERS, len(batch))) as pool:
                    results = pool.map(self.process_single_file, batch)
                    event_results.extend(results)
                    for result in results:
                        self.update_stats(result[0])
            
            # 批次后清理
            if (i + len(batch)) % config.GPU_CLEANUP_INTERVAL == 0:
                clear_memory()
            
            # 显示进度
            if config.SHOW_PROGRESS:
                self.show_progress()
        
        return event_results
    
    def update_stats(self, status):
        """更新统计信息"""
        if status == 'success':
            self.stats['processed'] += 1
        elif status == 'failed':
            self.stats['failed'] += 1
        elif status == 'skipped':
            self.stats['skipped'] += 1
    
    def show_progress(self):
        """显示进度信息"""
        total = self.stats['processed'] + self.stats['failed'] + self.stats['skipped']
        if total == 0:
            return
        
        elapsed = time.time() - self.stats['start_time']
        rate = total / elapsed if elapsed > 0 else 0
        eta = (self.stats['total_files'] - total) / rate if rate > 0 else 0
        
        self.logger.info(
            f"Progress: {total}/{self.stats['total_files']} "
            f"({self.stats['processed']} OK, {self.stats['failed']} failed, "
            f"{self.stats['skipped']} skipped) "
            f"Rate: {rate:.1f} files/s, ETA: {eta/60:.1f} min"
        )
    
    def save_summary(self):
        """保存处理汇总"""
        if not config.SUMMARY_CONFIG['create_summary']:
            return
        
        # 使用绝对路径
        output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
        summary_file = os.path.join(
            output_dir_abs, 
            f"processing_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.{config.SUMMARY_CONFIG['summary_format']}"
        )
        
        summary_data = {
            'processing_time': self.stats['end_time'] - self.stats['start_time'],
            'total_files': self.stats['total_files'],
            'processed': self.stats['processed'],
            'failed': self.stats['failed'],
            'skipped': self.stats['skipped'],
            'success_rate': self.stats['processed'] / max(self.stats['total_files'], 1),
            'results': self.results if config.SUMMARY_CONFIG['include_failed'] else 
                      [r for r in self.results if r[0] == 'success']
        }
        
        if config.SUMMARY_CONFIG['summary_format'] == 'json':
            with open(summary_file, 'w', encoding='utf-8') as f:
                json.dump(summary_data, f, indent=2, default=str)
        
        elif config.SUMMARY_CONFIG['summary_format'] == 'csv':
            with open(summary_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['Status', 'File', 'Details'])
                for result in self.results:
                    writer.writerow(result)
        
        self.logger.info(f"Summary saved to: {summary_file}")
    
    def run(self):
        """运行批处理"""
        self.stats['start_time'] = time.time()
        
        # 检查系统资源
        if not self.check_system_resources():
            self.logger.warning("System resources may be insufficient")
        
        # 获取所有事件目录（使用绝对路径）
        input_dir_abs = os.path.abspath(config.INPUT_DIR)
        event_dirs = [d for d in glob.glob(os.path.join(input_dir_abs, "*")) 
                     if os.path.isdir(d)]
        event_dirs.sort()
        
        if not event_dirs:
            self.logger.error(f"No event directories found in {input_dir_abs}")
            return
        
        # 统计总文件数
        for event_dir in event_dirs:
            for ext in config.FILE_FILTERS['extensions']:
                self.stats['total_files'] += len(glob.glob(os.path.join(event_dir, f"*{ext}")))
        
        self.logger.info(f"Found {len(event_dirs)} events with {self.stats['total_files']} total files")
        
        # 处理每个事件
        for idx, event_dir in enumerate(event_dirs):
            self.logger.info(f"\n{'='*60}")
            self.logger.info(f"Event {idx+1}/{len(event_dirs)}: {os.path.basename(event_dir)}")
            self.logger.info(f"{'='*60}")
            
            try:
                event_results = self.process_event(event_dir)
                self.results.extend(event_results)
                
                # 保存失败文件列表
                for status, file_path, details in event_results:
                    if status == 'failed':
                        self.failed_files.append((file_path, details))
                
            except Exception as e:
                # 安全地处理异常消息
                error_msg = str(e).replace('%', '%%')
                self.logger.error(f"Error processing event {event_dir}: {error_msg}")
                self.logger.debug(traceback.format_exc())
                if not config.ERROR_HANDLING['continue_on_error']:
                    break
        
        self.stats['end_time'] = time.time()
        
        # 最终报告
        self.show_final_report()
        
        # 保存汇总
        self.save_summary()
        
        # 保存失败文件列表
        if self.failed_files:
            self.save_failed_files()
    
    def show_final_report(self):
        """显示最终报告"""
        duration = self.stats['end_time'] - self.stats['start_time']
        
        self.logger.info(f"\n{'='*60}")
        self.logger.info("PROCESSING COMPLETED")
        self.logger.info(f"{'='*60}")
        self.logger.info(f"Total time: {duration/60:.1f} minutes")
        self.logger.info(f"Total files: {self.stats['total_files']}")
        self.logger.info(f"Processed: {self.stats['processed']}")
        self.logger.info(f"Failed: {self.stats['failed']}")
        self.logger.info(f"Skipped: {self.stats['skipped']}")
        self.logger.info(f"Success rate: {self.stats['processed']/max(self.stats['total_files'],1)*100:.1f}%%")
        
        if self.stats['processed'] > 0:
            self.logger.info(f"Average time per file: {duration/self.stats['processed']:.1f} seconds")
    
    def save_failed_files(self):
        """保存失败文件列表"""
        # 使用绝对路径
        output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
        failed_log = os.path.join(output_dir_abs, "failed_files.log")
        with open(failed_log, 'w', encoding='utf-8') as f:
            f.write(f"Failed files report - {datetime.now()}\n")
            f.write(f"{'='*60}\n")
            for file_path, reason in self.failed_files:
                f.write(f"{file_path}: {reason}\n")
        self.logger.info(f"Failed files list saved to: {failed_log}")

def main():
    """主函数"""
    # 确保使用绝对路径
    input_dir_abs = os.path.abspath(config.INPUT_DIR)
    output_dir_abs = os.path.abspath(config.OUTPUT_DIR)
    
    # 确保输出目录存在
    os.makedirs(output_dir_abs, exist_ok=True)
    
    # 设置日志
    logger = setup_logging()
    
    logger.info("Earthquake Waveform Batch Processing System (Safe Version)")
    logger.info(f"Configuration loaded from: batch_config.py")
    logger.info(f"Input directory: {input_dir_abs}")
    logger.info(f"Output directory: {output_dir_abs}")
    
    # 显示CuPy状态
    if CUPY_AVAILABLE:
        logger.info("CuPy is available for GPU acceleration")
    else:
        logger.info("CuPy is not available, will use CPU only")
    
    # 创建处理器并运行
    processor = BatchProcessor(logger)
    
    try:
        processor.run()
    except KeyboardInterrupt:
        logger.info("\nProcessing interrupted by user")
    except Exception as e:
        # 安全地处理异常消息，避免格式化错误
        error_msg = str(e).replace('%', '%%').replace('{', '{{').replace('}', '}}')
        logger.error(f"Unexpected error: {error_msg}")
        logger.debug(traceback.format_exc())
    finally:
        # 最终清理
        clear_memory()
        gc.collect()

if __name__ == '__main__':
    mp.freeze_support()
    main()