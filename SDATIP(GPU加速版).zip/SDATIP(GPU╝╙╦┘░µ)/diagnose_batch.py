#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
批处理诊断脚本 - 用于检查文件和配置问题
"""

import os
import glob
import sys
import batch_config as config
import obspy

def diagnose_files():
    """诊断输入文件情况"""
    print("=" * 60)
    print("批处理诊断报告")
    print("=" * 60)
    
    # 1. 检查输入目录
    input_dir = os.path.abspath(config.INPUT_DIR)
    print(f"\n1. 输入目录: {input_dir}")
    if not os.path.exists(input_dir):
        print("   ❌ 输入目录不存在!")
        return
    print("   ✓ 输入目录存在")
    
    # 2. 获取事件目录
    event_dirs = [d for d in glob.glob(os.path.join(input_dir, "*")) 
                  if os.path.isdir(d)]
    event_dirs.sort()
    print(f"\n2. 事件目录数量: {len(event_dirs)}")
    
    # 3. 统计文件
    total_files = 0
    file_details = {}
    duplicate_files = []
    
    for event_dir in event_dirs:
        event_name = os.path.basename(event_dir)
        print(f"\n   事件: {event_name}")
        
        # 获取所有匹配的文件
        all_files = []
        files_by_ext = {}
        
        for ext in config.FILE_FILTERS['extensions']:
            pattern = os.path.join(event_dir, f"*{ext}")
            files = glob.glob(pattern)
            files_by_ext[ext] = files
            all_files.extend(files)
            print(f"      {ext}: {len(files)} 个文件")
        
        # 检查重复
        unique_files = list(set(all_files))
        if len(unique_files) != len(all_files):
            print(f"      ⚠️  发现重复文件!")
            duplicate_files.append((event_name, len(all_files) - len(unique_files)))
        
        # 检查文件有效性
        valid_files = []
        invalid_files = []
        
        for f in unique_files:
            try:
                # 检查文件大小
                size = os.path.getsize(f)
                if size < config.FILE_FILTERS['min_size']:
                    invalid_files.append((f, "文件太小"))
                    continue
                if size > config.FILE_FILTERS['max_size']:
                    invalid_files.append((f, "文件太大"))
                    continue
                
                # 尝试读取文件头
                if config.VALIDATE_SAC:
                    st = obspy.read(f, headonly=True)
                    if len(st) == 0:
                        invalid_files.append((f, "空数据流"))
                        continue
                
                valid_files.append(f)
            except Exception as e:
                invalid_files.append((f, str(e)))
        
        print(f"      有效文件: {len(valid_files)}")
        print(f"      无效文件: {len(invalid_files)}")
        
        if invalid_files:
            print("      无效文件列表:")
            for f, reason in invalid_files[:5]:  # 只显示前5个
                print(f"         - {os.path.basename(f)}: {reason}")
            if len(invalid_files) > 5:
                print(f"         ... 还有 {len(invalid_files) - 5} 个")
        
        file_details[event_name] = {
            'total': len(unique_files),
            'valid': len(valid_files),
            'invalid': len(invalid_files)
        }
        total_files += len(unique_files)
    
    # 4. 汇总
    print(f"\n3. 文件汇总:")
    print(f"   总文件数: {total_files}")
    print(f"   有效文件: {sum(d['valid'] for d in file_details.values())}")
    print(f"   无效文件: {sum(d['invalid'] for d in file_details.values())}")
    
    if duplicate_files:
        print(f"\n4. 重复文件问题:")
        for event, count in duplicate_files:
            print(f"   {event}: {count} 个重复")
        print("\n   💡 建议: 文件扩展名大小写可能导致重复计数")
    
    # 5. 配置检查
    print(f"\n5. 配置检查:")
    print(f"   批处理大小: {config.BATCH_SIZE}")
    print(f"   最大工作进程: {config.MAX_WORKERS}")
    print(f"   跳过绘图: {config.SKIP_PLOTS}")
    print(f"   保存中间结果: {config.SAVE_INTERMEDIATE}")
    
    # 6. 资源检查
    print(f"\n6. 系统资源:")
    try:
        import psutil
        import multiprocessing as mp
        
        mem = psutil.virtual_memory()
        print(f"   CPU核心: {mp.cpu_count()}")
        print(f"   内存: {mem.total/1024**3:.1f}GB (使用 {mem.percent:.1f}%)")
        
        # GPU检查
        try:
            import cupy as cp
            gpu_count = cp.cuda.runtime.getDeviceCount()
            print(f"   GPU: {gpu_count} 个可用")
        except:
            print(f"   GPU: 不可用")
    except:
        print("   无法获取系统资源信息")
    
    print("\n" + "=" * 60)
    
    # 返回诊断结果
    return {
        'total_files': total_files,
        'file_details': file_details,
        'has_duplicates': len(duplicate_files) > 0
    }

def test_single_file():
    """测试单个文件处理"""
    print("\n7. 测试单个文件处理:")
    
    # 找一个测试文件
    input_dir = os.path.abspath(config.INPUT_DIR)
    test_file = None
    
    for event_dir in glob.glob(os.path.join(input_dir, "*")):
        if os.path.isdir(event_dir):
            for ext in config.FILE_FILTERS['extensions']:
                files = glob.glob(os.path.join(event_dir, f"*{ext}"))
                if files:
                    test_file = files[0]
                    break
        if test_file:
            break
    
    if not test_file:
        print("   ❌ 找不到测试文件")
        return
    
    print(f"   测试文件: {os.path.basename(test_file)}")
    
    try:
        # 读取文件
        st = obspy.read(test_file)
        data = st[0].data
        print(f"   ✓ 文件读取成功 (数据点: {len(data)})")
        
        # 尝试处理
        from single_batch import solutionset
        event_name = os.path.basename(os.path.dirname(test_file))
        output_dir = os.path.join(config.OUTPUT_DIR, "test")
        os.makedirs(output_dir, exist_ok=True)
        
        print("   正在测试处理...")
        success, result = solutionset(
            f"test_{os.path.basename(test_file)}", 
            data, 
            output_dir,
            skip_plots=True,
            save_intermediate=False
        )
        
        if success:
            print("   ✓ 处理成功")
        else:
            print(f"   ❌ 处理失败: {result}")
            
    except Exception as e:
        print(f"   ❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    # 运行诊断
    result = diagnose_files()
    
    # 可选：测试单个文件
    if '--test' in sys.argv:
        test_single_file()
    
    # 建议
    print("\n建议:")
    if result['has_duplicates']:
        print("- 修改文件扩展名检测逻辑，避免重复计数")
    
    if result['total_files'] > 100:
        print("- 考虑减小批处理大小以降低内存使用")
    
    print("- 运行 'python diagnose_batch.py --test' 测试单个文件处理")
    print("- 检查 output 目录中的日志文件获取更多信息")