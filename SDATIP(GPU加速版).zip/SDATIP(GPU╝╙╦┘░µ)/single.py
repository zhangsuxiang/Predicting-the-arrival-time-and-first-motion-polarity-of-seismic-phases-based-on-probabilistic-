# single.py - GPU accelerated version
import os
import numpy as np
import cupy as cp
import scipy.io as scio
from Waveform import Waveform
import plotresult
import plotresult_graduate_1

def solutionset(name, data, outputdir):
    """
    对单一波形数据执行全流程分析（GPU加速版本）：
      1. 数据导入与预处理
      2. 构建状态并计算 Markov 转移和振幅概率
      3. 保存总体 .mat 文件和每个解的 timeprob .mat
      4. 调用两个 plotprob 函数生成图形
      5. 记录每个解的关键参数到日志
    """
    # 1. 确保输出目录存在（Windows兼容）
    outputdir = os.path.normpath(outputdir)
    os.makedirs(outputdir, exist_ok=True)
    
    # 检查GPU可用性
    use_gpu = False
    try:
        gpu_count = cp.cuda.runtime.getDeviceCount()
        if gpu_count > 0:
            use_gpu = True
            # 修复：安全获取GPU属性
            try:
                device_props = cp.cuda.runtime.getDeviceProperties(0)
                
                # 尝试不同的方式获取GPU名称
                try:
                    if hasattr(device_props, 'name'):
                        gpu_name_raw = device_props.name
                    elif isinstance(device_props, dict) and 'name' in device_props:
                        gpu_name_raw = device_props['name']
                    else:
                        gpu_name_raw = "GPU 0"
                    
                    # 处理字节串或字符串
                    if isinstance(gpu_name_raw, bytes):
                        gpu_name = gpu_name_raw.decode('utf-8', errors='replace')
                    else:
                        gpu_name = str(gpu_name_raw)
                    
                    # 清理特殊字符
                    gpu_name = ''.join(c for c in gpu_name if c.isprintable())
                except:
                    gpu_name = "Unknown GPU"
                
                # 获取GPU内存
                try:
                    if hasattr(device_props, 'totalGlobalMem'):
                        gpu_memory = device_props.totalGlobalMem / 1024**3
                    elif isinstance(device_props, dict) and 'totalGlobalMem' in device_props:
                        gpu_memory = device_props['totalGlobalMem'] / 1024**3
                    else:
                        gpu_memory = 0
                except:
                    gpu_memory = 0
                
                # 获取计算能力
                try:
                    if hasattr(device_props, 'major') and hasattr(device_props, 'minor'):
                        major = device_props.major
                        minor = device_props.minor
                    elif isinstance(device_props, dict) and 'major' in device_props and 'minor' in device_props:
                        major = device_props['major']
                        minor = device_props['minor']
                    else:
                        major, minor = 0, 0
                except:
                    major, minor = 0, 0
                
                print(f"GPU available: {gpu_name} ({gpu_memory:.1f} GB)")
                if major > 0:
                    print(f"Compute capability: {major}.{minor}")
            except Exception as e:
                print(f"GPU property detection warning: {e}")
                print("GPU detected but properties unavailable")
        else:
            print("No GPU detected, using CPU")
    except Exception as e:
        print(f"GPU detection failed: {e}")
        print("Using CPU instead")
        use_gpu = False
    
    print(f"[1/4] 开始处理 {name!r}")
    
    # 2. 数据导入与预处理（GPU加速）
    a = Waveform(name, use_gpu=use_gpu)
    a.importdata(data, 0.01)
    a.analyzedata()
    a.interpolate(1)
    a.denseunique()
    a.denselong(2.5, 200)   # 5/2 -> 2.5
    a.extremearr()
    a.densebin()
    print("    ➤ 预处理完成")
    
    # 3. 构建状态并计算矩阵与概率（GPU加速）
    b = a.constructstate()
    c, c_num = b.markovmatrix()
    d = b.ampprobcalculate()
    print("    ➤ Markov 矩阵与振幅概率计算完成")
    
    # 4. 保存总体 .mat（将GPU数据转到CPU）
    summary_mat = os.path.join(outputdir, f"{a.name}.mat")
    
    # 确保数据在CPU上
    matrix_cpu = b.matrix if isinstance(b.matrix, np.ndarray) else cp.asnumpy(b.matrix)
    ampprob_cpu = np.array(b.ampprob_up, dtype=np.float64)
    
    # 安全处理threshold
    if hasattr(a, 'threshold'):
        threshold_cpu = a.threshold if isinstance(a.threshold, np.ndarray) else cp.asnumpy(a.threshold)
    else:
        threshold_cpu = np.array([])  # 默认空数组
    
    # 安全处理其他可能的GPU数组
    Apeak_cpu = b.Apeak if isinstance(b.Apeak, np.ndarray) else (cp.asnumpy(b.Apeak) if hasattr(cp, 'ndarray') and isinstance(b.Apeak, cp.ndarray) else b.Apeak)
    eigvalue_cpu = b.eigvalue if isinstance(b.eigvalue, np.ndarray) else (cp.asnumpy(b.eigvalue) if hasattr(cp, 'ndarray') and isinstance(b.eigvalue, cp.ndarray) else b.eigvalue)
    bigeig_cpu = b.bigeig if isinstance(b.bigeig, np.ndarray) else (cp.asnumpy(b.bigeig) if hasattr(cp, 'ndarray') and isinstance(b.bigeig, cp.ndarray) else b.bigeig)
    
    scio.savemat(
        summary_mat,
        {
            "transitionmatrix": matrix_cpu,
            "ampprob": ampprob_cpu,
            "Apeak": Apeak_cpu,
            "samplelength": b.samplength,
            "eigvalue": eigvalue_cpu,
            "bigeig": bigeig_cpu,
            "threshold": threshold_cpu,
        }
    )
    print(f"    ➤ 已保存总体 MAT：{summary_mat}")
    
    # 5. 打开日志文件，一次性写入所有解
    log_path = os.path.join(outputdir, f"{name}.txt")
    with open(log_path, "a", encoding='utf-8') as f_log:
        # 6. 逐个解处理
        for i in range(c_num):
            b.estimation(i)
            
            # 6.1 保存 timeprob.mat（确保数据在CPU上）
            timeprob_mat = os.path.join(outputdir, f"{a.name}_timeprob_{i}.mat")
            timeprob_data = c[i] if isinstance(c[i], np.ndarray) else cp.asnumpy(c[i])
            scio.savemat(timeprob_mat, {"timeprob": timeprob_data})
            print(f"    ➤ 已保存 timeprob MAT({i})：{timeprob_mat}")
            
            # 6.2 绘图（确保数据在CPU上进行绘图）
            if use_gpu and hasattr(a, 'use_gpu') and a.use_gpu:
                # 创建一个临时的CPU版本用于绘图
                a_cpu = Waveform(a.name, use_gpu=False)
                
                # 复制必要的属性到CPU版本
                for attr in ['data', 'denselongdata', 'longtimestamp', 'timestamp', 
                           'densetimestamp', 'cut', 'threshold']:
                    if hasattr(a, attr):
                        val = getattr(a, attr)
                        if isinstance(val, cp.ndarray):
                            setattr(a_cpu, attr, cp.asnumpy(val))
                        else:
                            setattr(a_cpu, attr, val)
                
                # 复制其他必要属性
                for attr in ['longlength', 'length', 'name', 'time', 'maxamp', 
                           'minamp', 'maxampindex', 'minampindex', 'delta', 'densedelta',
                           'longextremearr', 'dense_abs', 'denselongabs']:
                    if hasattr(a, attr):
                        val = getattr(a, attr)
                        if isinstance(val, cp.ndarray):
                            setattr(a_cpu, attr, cp.asnumpy(val))
                        else:
                            setattr(a_cpu, attr, val)
                
                plotresult.plotprob(a_cpu, b, i, a.name, outputdir)
                plotresult_graduate_1.plotprob(a_cpu, b, i, a.name, outputdir)
            else:
                plotresult.plotprob(a, b, i, a.name, outputdir)
                plotresult_graduate_1.plotprob(a, b, i, a.name, outputdir)
            
            # 6.3 写日志（确保数据在CPU上进行计算）
            c_i_cpu = c[i] if isinstance(c[i], np.ndarray) else cp.asnumpy(c[i])
            d_cpu = d if isinstance(d, np.ndarray) else cp.asnumpy(d)
            overall_up = float(np.sum(c_i_cpu * d_cpu))
            
            log_line = (
                f"{name} solution id:{i} "
                f"arrivaltime:{b.arrivalestimate:.3f} "
                f"overall up:{overall_up:.5f} "
                f"up:{b.polarityup:.3f} "
                f"down:{b.polaritydown:.3f} "
                f"unknown:{b.polarityunknown:.3f}\n"
            )
            f_log.write(log_line)
    
    print(f"[4/4] 全部处理完成，日志文件：{log_path}")
    
    # 清理GPU内存
    if use_gpu:
        try:
            mempool = cp.get_default_memory_pool()
            pinned_mempool = cp.get_default_pinned_memory_pool()
            mempool.free_all_blocks()
            pinned_mempool.free_all_blocks()
        except Exception as e:
            print(f"GPU memory cleanup warning: {e}")