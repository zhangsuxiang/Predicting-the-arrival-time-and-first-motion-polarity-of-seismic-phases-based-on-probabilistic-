# batch_config.py - 批处理配置文件

import os

# ========== 基本配置 ==========
# 输入输出目录
INPUT_DIR = os.path.join('.', 'input')
OUTPUT_DIR = os.path.join('.', 'output')

# ========== 处理配置 ==========
# 批处理大小（每批处理的波形文件数量）
BATCH_SIZE = 10

# 是否跳过绘图（跳过可大幅提升处理速度）
SKIP_PLOTS = False

# 是否保存中间结果（.mat文件）
SAVE_INTERMEDIATE = True

# ========== 性能配置 ==========
# 最大并发进程数（设为0则自动使用CPU核心数-1）
MAX_WORKERS = 0

# 内存使用率阈值（%）- 超过此值将触发内存清理
MEMORY_THRESHOLD = 80

# 单个波形处理超时时间（秒）
PROCESS_TIMEOUT = 2000

# ========== GPU配置 ==========
# 是否强制使用CPU（即使有GPU可用）
FORCE_CPU = False

# GPU内存清理频率（每处理N个文件清理一次）
GPU_CLEANUP_INTERVAL = 5

# ========== 日志配置 ==========
# 日志级别（DEBUG, INFO, WARNING, ERROR）
LOG_LEVEL = "INFO"

# 是否保存详细日志文件
SAVE_DETAILED_LOG = True

# 日志文件名格式
LOG_FILENAME = "batch_processing_{timestamp}.log"

# ========== 高级配置 ==========
# 波形处理参数
WAVEFORM_PARAMS = {
    'delta': 0.01,                # 采样时间间隔
    'interpolate_coef': 1,        # 插值系数
    'hv_coefficient': 2.5,        # 水平-垂直系数
    'min_insert_co': 200,         # 最小插入系数
}

# 文件过滤器
FILE_FILTERS = {
    'extensions': ['.SAC'],  # 支持的文件扩展名
    'min_size': 1024,                # 最小文件大小（字节）
    'max_size': 100 * 1024 * 1024,  # 最大文件大小（100MB）
}

# 错误处理
ERROR_HANDLING = {
    'max_retries': 2,             # 失败重试次数
    'retry_delay': 5,             # 重试延迟（秒）
    'continue_on_error': True,    # 出错时是否继续处理其他文件
}

# ========== 输出配置 ==========
# 结果汇总配置
SUMMARY_CONFIG = {
    'create_summary': True,       # 是否创建汇总报告
    'summary_format': 'csv',      # 汇总格式（csv, json, xlsx）
    'include_failed': True,       # 是否包含失败文件
}

# 图像输出配置（当SKIP_PLOTS=False时生效）
PLOT_CONFIG = {
    'dpi': 300,                   # 图像DPI（降低可加快处理）
    'formats': ['png'],           # 输出格式列表 ['png', 'pdf', 'eps']
    'compress_png': True,         # 是否压缩PNG文件
}

# ========== 批处理策略 ==========
# 处理优先级（可选：'time', 'size', 'name'）
PROCESS_PRIORITY = 'time'

# 是否按事件分组处理
GROUP_BY_EVENT = True

# 并行策略（'process', 'thread', 'sequential'）
PARALLEL_STRATEGY = 'process'

# ========== 监控配置 ==========
# 是否启用进度条
SHOW_PROGRESS = True

# 状态更新间隔（秒）
STATUS_UPDATE_INTERVAL = 10

# 是否发送完成通知（需要配置邮件或其他通知方式）
SEND_NOTIFICATION = False

# ========== 数据验证 ==========
# 是否在处理前验证SAC文件
VALIDATE_SAC = True

# 是否检查输出完整性
VERIFY_OUTPUT = True

# ========== 用户自定义函数 ==========
def custom_filter(sac_file):
    """
    用户自定义文件过滤器
    返回True表示处理该文件，False表示跳过
    """
    # 示例：跳过文件名包含'test'的文件
    if 'test' in os.path.basename(sac_file).lower():
        return False
    return True

def custom_naming(event_name, waveform_name):
    """
    用户自定义输出文件命名规则
    """
    # 示例：使用下划线连接
    return f"{event_name}_{waveform_name}"

# ========== 环境检查 ==========
def validate_config():
    """验证配置的有效性"""
    import multiprocessing as mp
    
    # 自动设置最大工作进程数
    global MAX_WORKERS
    if MAX_WORKERS == 0:
        MAX_WORKERS = max(1, mp.cpu_count() - 1)
    
    # 确保批处理大小合理
    global BATCH_SIZE
    BATCH_SIZE = max(1, min(BATCH_SIZE, 100))
    
    # 验证目录
    if not os.path.exists(INPUT_DIR):
        raise ValueError(f"Input directory not found: {INPUT_DIR}")
    
    return True

# 运行配置验证
try:
    validate_config()
except Exception as e:
    print(f"Configuration error: {e}")