import numpy as np
import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pmi

def plotwaveform_dense(a,b,threshold_id,arrivaltime,pmiarray):
    fig = plt.figure(figsize=(16, 9))
    plt.rcParams["font.weight"] = "bold"
    plt.rcParams["axes.labelweight"] = "bold"
    ax1 = fig.add_axes([0.1, 0.5, 0.8, 0.4])
    colori = np.zeros([b.num, 3])
    threshold=b.threshold[threshold_id]
    longarray = np.ones(a.longlength + 1)
    zeroindex = np.where(abs(a.denselongdata) <= threshold)[0]
    ax1.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp[zeroindex], a.denselongdata[zeroindex], linewidth=2.5, color='k', linestyle='-')
    ax1.fill_between([0, a.longtimestamp[-1]], [threshold*(-1),threshold*(-1)],
                     [threshold,threshold], color=colori[i, :],
                     alpha=0.03)
    ax1.plot(a.longcutsolution[threshold_id]*np.ones(10), np.linspace(-1*b.upthreshold[-1], b.upthreshold[-1],10), linewidth=2.5, color='k', linestyle='-')
    ax1.set(ylim=(-1*b.upthreshold[-1], b.upthreshold[-1]))
    ax1.set_xticks(np.linspace(0, a.longtimestamp[-1], 5))
    ax1.set_xticklabels(
        ['%.2f' % (0), '%.2f' % (a.longtimestamp[-1] / 4), '%.2f' % (a.longtimestamp[-1] / 4 * 2), '%.2f' % (a.longtimestamp[-1] / 4 * 3),
         '%.2f' % (a.longtimestamp[-1])], {'fontweight': 'bold'})
    ax1.set_yticks(np.linspace(0, b.upthreshold[-1], 5))
    ax1.set_yticklabels(['%.2f' % (0), '%.2f' % (b.upthreshold[-1] / 4), '%.2f' % (b.upthreshold[-1] / 4 * 2),
                         '%.2f' % (b.upthreshold[-1] / 4 * 3), '%.2f' % (b.upthreshold[-1])], {'fontweight': 'bold'})
    ax1.tick_params(direction='out', size=20)
    ax1.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
    ax1.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
    bwith = 2
    ax1.spines['bottom'].set_linewidth(bwith)
    ax1.spines['left'].set_linewidth(bwith)
    ax1.spines['top'].set_linewidth(bwith)
    ax1.spines['right'].set_linewidth(bwith)

    ax2 = fig.add_axes([0.1, 0.1, 0.8, 0.3])
    colori = np.zeros([b.num, 3])
    longarray = np.ones(a.longlength + 1)
    zeroindex=np.where(abs(a.denselongdata)<=threshold)[0]
    longarray[zeroindex] = 0
    mivalue = np.zeros(a.longlength)
    pmivalue = np.zeros(a.longlength)
    longcutsolution = np.zeros(a.longlength)
    for i in range(0,a.longlength):
        [mivalue[i], pmivalue[i], longcutsolution[i]] = pmi.maxpmi(longarray, i)
    ax2.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')
    ax2.set(ylim=(0, np.max(pmivalue)*1.1))
    ax2.set_xticks(np.linspace(0, a.longtimestamp[-1], 5))
    ax2.set_xticklabels(
        ['%.2f' % (0), '%.2f' % (a.longtimestamp[-1] / 4), '%.2f' % (a.longtimestamp[-1] / 4 * 2),
         '%.2f' % (a.longtimestamp[-1] / 4 * 3),
         '%.2f' % (a.longtimestamp[-1])], {'fontweight': 'bold'})

    ax2.set_yticks(np.linspace(0, np.max(pmivalue)*1.1, 5))
    ax2.set_yticklabels(['%.2f' % (0), '%.2f' % (np.max(pmivalue)*1.1 / 4), '%.2f' % (np.max(pmivalue)*1.1 / 4 * 2),
                         '%.2f' % (np.max(pmivalue)*1.1 / 4 * 3), '%.2f' % (np.max(pmivalue)*1.1)], {'fontweight': 'bold'})
    ax2.tick_params(direction='out', size=20)
    ax2.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
    ax2.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
    bwith = 2
    ax2.spines['bottom'].set_linewidth(bwith)
    ax2.spines['left'].set_linewidth(bwith)
    ax2.spines['top'].set_linewidth(bwith)
    ax2.spines['right'].set_linewidth(bwith)


def plotwaveform_extreme(a,b,threshold,arrivaltime,pmiarray):
    fig = plt.figure(figsize=(16, 9))
    plt.rcParams["font.weight"] = "bold"
    plt.rcParams["axes.labelweight"] = "bold"
    ax1 = fig.add_axes([0.1, 0.5, 0.8, 0.4])
    colori = np.zeros([b.num, 3])
    longarray = np.ones(a.longlength + 1)
    zeroindex = np.where(abs(a.longextremearr) <= threshold)[0]
    ax1.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')

    ax1.plot(a.longtimestamp, a.denselongdata, linewidth=2.5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp, a.longextremearr, linewidth=2.5, color='k', linestyle='-')

    ax1.fill_between([0, downt[i], upt[i]], [b.downthreshold[i], b.downthreshold[i], b.upthreshold[i]],
                     [b.upthreshold[i], b.upthreshold[i], b.upthreshold[i]], color=colori[i, :],
                     alpha=0.03)
    ax1.fill_betweenx([-1 * b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]], [downt[i], downt[i], upt[i]],
                      [upt[i], upt[i], upt[i]], color=colori[i, :],
                      alpha=0.03)
    ax1.plot(a.longcutsolution[i]*np.ones(10), np.linspace([]), linewidth=2.5, color='k', linestyle='-')
    ax1.set(ylim=(0, b.upthreshold[-1]))
    ax1.set_xticks(np.linspace(0, np.max(prob1), 5))
    ax1.set_xticklabels(
        ['%.2f' % (0), '%.2f' % (np.max(prob1) / 4), '%.2f' % (np.max(prob1) / 4 * 2), '%.2f' % (np.max(prob1) / 4 * 3),
         '%.2f' % (np.max(prob1))], {'fontweight': 'bold'})
    ax1.set_yticks(np.linspace(0, b.upthreshold[-1], 5))
    ax1.set_yticklabels(['%.2f' % (0), '%.2f' % (b.upthreshold[-1] / 4), '%.2f' % (b.upthreshold[-1] / 4 * 2),
                         '%.2f' % (b.upthreshold[-1] / 4 * 3), '%.2f' % (b.upthreshold[-1])], {'fontweight': 'bold'})
    ax1.tick_params(direction='out', size=20)
    ax1.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
    ax1.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
    bwith = 2
    ax1.spines['bottom'].set_linewidth(bwith)
    ax1.spines['left'].set_linewidth(bwith)
    ax1.spines['top'].set_linewidth(bwith)
    ax1.spines['right'].set_linewidth(bwith)

    ax2 = fig.add_axes([0.1, 0.1, 0.8, 0.3])
    colori = np.zeros([b.num, 3])
    longarray = np.ones(a.longlength + 1)


    ax2.set(ylim=(0, b.upthreshold[-1]))
    ax2.set_xticks(np.linspace(0, np.max(prob1), 5))
    ax2.set_xticklabels(
        ['%.2f' % (0), '%.2f' % (np.max(prob1) / 4), '%.2f' % (np.max(prob1) / 4 * 2), '%.2f' % (np.max(prob1) / 4 * 3),
         '%.2f' % (np.max(prob1))], {'fontweight': 'bold'})
    ax2.set_yticks(np.linspace(0, b.upthreshold[-1], 5))
    ax2.set_yticklabels(['%.2f' % (0), '%.2f' % (b.upthreshold[-1] / 4), '%.2f' % (b.upthreshold[-1] / 4 * 2),
                         '%.2f' % (b.upthreshold[-1] / 4 * 3), '%.2f' % (b.upthreshold[-1])], {'fontweight': 'bold'})
    ax2.tick_params(direction='out', size=20)
    ax2.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
    ax2.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
    bwith = 2
    ax2.spines['bottom'].set_linewidth(bwith)
    ax2.spines['left'].set_linewidth(bwith)
    ax2.spines['top'].set_linewidth(bwith)
    ax2.spines['right'].set_linewidth(bwith)

def plotmatrix(b, name, outputdir):

    fig = plt.figure(figsize=(15, 15))

    plt.rcParams["font.weight"] = "bold"
    plt.rcParams["axes.labelweight"] = "bold"

    ax1 = fig.add_axes([0.1, 0.8, 0.1, 0.8])
    matriximage = ax1.imshow(np.real(b.mattrix))
    ax1.set_xticks(np.arange(len(farmers)))
    ax1.set_yticks(np.arange(len(vegetables)))
    ax1.set_xticklabels(farmers)
    ax1.set_yticklabels(vegetables)
    ax1.set_title("Transition Matrix (log(prob))")
    plt.show()


