import os
import numpy as np
import scipy.io as scio
from Waveform import Waveform
import plotresult
import plotresult_graduate_1


def solutionset(name, data, outputdir):
    """
    对单一波形数据执行全流程分析：
      1. 数据导入与预处理
      2. 构建状态并计算 Markov 转移和振幅概率
      3. 保存总体 .mat 文件和每个解的 timeprob .mat
      4. 调用两个 plotprob 函数生成图形
      5. 记录每个解的关键参数到日志
    """
    # 1. 确保输出目录存在
    os.makedirs(outputdir, exist_ok=True)

    print(f"[1/4] 开始处理 {name!r}")
    # 2. 数据导入与预处理
    a = Waveform(name)
    a.importdata(data, 0.01)
    a.analyzedata()
    a.interpolate(1)
    a.denseunique()
    a.denselong(2.5, 200)   # 5/2 -> 2.5
    a.extremearr()
    a.densebin()
    print("    ➤ 预处理完成")

    # 3. 构建状态并计算矩阵与概率
    b = a.constructstate()
    c, c_num = b.markovmatrix()
    d = b.ampprobcalculate()
    print("    ➤ Markov 矩阵与振幅概率计算完成")

    # 4. 保存总体 .mat
    summary_mat = os.path.join(outputdir, f"{a.name}.mat")
    scio.savemat(
        summary_mat,
        {
            "transitionmatrix": np.array(b.matrix),
            "ampprob": np.array(b.ampprob_up, dtype=np.float64),
            "Apeak": b.Apeak,
            "samplelength": b.samplength,
            "eigvalue": b.eigvalue,
            "bigeig": b.bigeig,
            "threshold": a.threshold,
        }
    )
    print(f"    ➤ 已保存总体 MAT：{summary_mat}")

    # 5. 打开日志文件，一次性写入所有解
    log_path = os.path.join(outputdir, f"{name}.txt")
    with open(log_path, "a") as f_log:
        # 6. 逐个解处理
        for i in range(c_num):
            b.estimation(i)

            # 6.1 保存 timeprob.mat
            timeprob_mat = os.path.join(outputdir, f"{a.name}_timeprob_{i}.mat")
            scio.savemat(timeprob_mat, {"timeprob": c[i]})
            print(f"    ➤ 已保存 timeprob MAT({i})：{timeprob_mat}")

            # 6.2 绘图
            plotresult.plotprob(a, b, i, a.name, outputdir)
            plotresult_graduate_1.plotprob(a, b, i, a.name, outputdir)

            # 6.3 写日志
            overall_up = float(np.sum(c[i] * d))
            log_line = (
                f"{name} solution id:{i} "
                f"arrivaltime:{b.arrivalestimate:.3f} "
                f"overall up:{overall_up:.5f} "
                f"up:{b.polarityup:.3f} "
                f"down:{b.polaritydown:.3f} "
                f"unknown:{b.polarityunknown:.3f}\n"
            )
            f_log.write(log_line)

    print(f"[4/4] 全部处理完成，日志文件：{log_path}")