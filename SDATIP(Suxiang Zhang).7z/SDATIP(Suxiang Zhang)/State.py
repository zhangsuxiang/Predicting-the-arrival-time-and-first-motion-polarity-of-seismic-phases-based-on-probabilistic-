#State.py
import numpy as np
import sympy


class State():
    def __init__(self,name):
        self.name=name
        self.num = 0
        self.downthreshold = []
        self.upthreshold=[]
        self.sample = []
        self.chances=[]
        self.samplength = []
        self.xsquare = []
        self.pmi = []
        self.Apeak = []
        self.combo = []
        self.arrivaltimestamp=[]
        self.multiplesolution=1

    def addstate(self, downthreshold, upthreshold, noisesample, chances ,pmi, Apeak, arrivaltime):
        self.num = self.num + 1
        self.combo.append(1)
        self.downthreshold.append(downthreshold)
        self.upthreshold.append(upthreshold)
        self.sample.append(noisesample)
        self.chances.append(chances)
        self.samplength.append(len(noisesample))
        self.xsquare.append(np.sum((np.array(noisesample)) ** 2))
        self.pmi.append(pmi)
        self.Apeak.append(Apeak)
        self.arrivaltimestamp.append(arrivaltime)

    def addcombo(self, combonum, downthreshold, upthreshold, noisesample, chances, pmi, Apeak,arrivaltime):
        self.num = self.num + 1
        self.combo.append(combonum)
        self.downthreshold.append(downthreshold)
        self.upthreshold.append(upthreshold)
        self.sample.append(noisesample)
        self.chances.append(chances)
        samplength = []
        xsquare = []
        for i in range(0, combonum):
            samplength.append(len(noisesample[i]))
            xsquare.append(np.sum((np.array(noisesample[i])) ** 2))
        self.samplength.append(samplength)
        self.xsquare.append(xsquare)
        self.pmi.append(pmi)
        self.Apeak.append(Apeak)
        self.arrivaltimestamp.append(arrivaltime)

    def markovmatrix(self):
        self.matrix = np.zeros([self.num, self.num])
        for i in range(0,self.num):
            p12=[]
            if(self.combo[i]==1):
                if(i>0 and self.samplength[i]==self.samplength[i-1] and np.alltrue(self.sample[i]==self.sample[i-1])):
                    self.matrix[i]=self.matrix[i-1]
                    continue
                bestsigma = np.sqrt(self.xsquare[i] / self.samplength[i])
                for j in range(0,self.num):
                    p1 = sympy.erfc(self.downthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                    p2 = sympy.erfc(self.upthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                    p12.append(sympy.exp(-self.chances[i][0] * p2).evalf(300)-sympy.exp(-self.chances[i][0] * p1).evalf(300))
            else:
                for j in range(0,self.num):
                    p12combo = 0
                    for k in range(0,self.combo[i]):
                        bestsigma=np.sqrt(self.xsquare[i][k]/self.samplength[i][k])
                        p1 = sympy.erfc(self.downthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                        p2 = sympy.erfc(self.upthreshold[j] / sympy.sqrt(2) / bestsigma).evalf(300)
                        p12combo=p12combo+(sympy.exp(-self.chances[i][0] * p2).evalf(300)-sympy.exp(-self.chances[i][0] * p1).evalf(300))/self.combo[i]
                    p12.append(p12combo)
            self.matrix[i]=np.array(p12) / np.sum(p12)

        eigenvalue, featurevector = np.linalg.eig(np.matrix(self.matrix).T)
        bigeigvalue = np.sort(np.real(eigenvalue))[-5:]
        self.bigeig = np.around(bigeigvalue[::-1],3)
        eigindex = np.where(np.real(eigenvalue) > 0.98)[0]
        self.eigvalue = eigenvalue[eigindex]
        if (len(eigindex) == 1):
            eig = eigindex[0]
            timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
            timeprob = np.array(timeprob).flatten()
            self.timeprob = [abs(timeprob)]
            return self.timeprob, 1
        if (len(eigindex) == 2):
            likesignid = []
            likesignprob = []
            alpha=np.zeros([2,self.num])
            for i in range(0, 2):
                eig = eigindex[i]
                timeprob = np.real(abs(featurevector[:, eig]) / np.sum(abs(featurevector[:, eig])))
                alpha[i]= np.array(timeprob).flatten()
                timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
                timeprob = np.array(timeprob).flatten()
                if (np.sum(timeprob) / np.sum(abs(timeprob)) > 0.999):
                    likesignid.append(i)
                    likesignprob.append(timeprob)
            #unlikeid = np.setdiff1d(np.arange(0, 2), np.array(likesignid))[0]
            # search for first parameter k0p
            leftrange = -50
            rightrange = 50
            k = np.linspace(leftrange, rightrange, 1 + int(np.round((rightrange - leftrange) / 0.001)))
            bestfit = np.zeros(len(k))
            bestk0s = np.zeros(len(k))
            for i in range(0, len(k)):
                k0p = k[i]
                k1p = 1 - k[i]
                probp = k0p * alpha[0] + k1p * alpha[1]
                k0sco = k0p * np.dot(alpha[0], alpha[0]) + k1p * np.dot(alpha[0], alpha[1])
                k1sco = k1p * np.dot(alpha[1], alpha[1]) + k0p * np.dot(alpha[0], alpha[1])
                k0s = -1 * k1sco / (k0sco - k1sco)
                # k1s = k0sco / (k0sco - k1sco)
                k0srange = np.linspace(k0s - 1, k0s + 1, 401)
                ortho = np.zeros(len(k0srange))
                for j in range(0, len(k0srange)):
                    k0s = k0srange[j]
                    k1s = 1 - k0s
                    probs = k0s * alpha[0] + k1s * alpha[1]
                    ortho[j] = np.dot(abs(probp), abs(probs))
                bestfit[i] = np.min(ortho)
                k0sid=np.where(ortho == np.min(ortho))[0]
                bestk0s[i] = k0srange[k0sid]
            bestpair = np.where(bestfit == np.min(bestfit))[0][0]
            k0p=k[bestpair]
            k1p=1-k0p
            k0s=bestk0s[bestpair]
            k1s=1-k0s
            probp = k0p * alpha[0] + k1p * alpha[1]
            probs = k0s * alpha[0] + k1s * alpha[1]
            #print(bestpair)
            #print(k0p,k1p,k0s,k1s)
            solution=[]
            solution.append(abs(probp))
            solution.append(abs(probs))
            self.timeprob=solution
            return self.timeprob, 2
        if (len(eigindex) == 3):
            self.timeprob=[]
            for i in range(len(eigindex)):
                eig = eigindex[i]
                timeprob = np.real(abs(featurevector[:, eig]) / np.sum(abs(featurevector[:, eig])))
                timeprob = np.array(timeprob).flatten()
                self.timeprob.append(abs(timeprob))
            return self.timeprob, 3
        '''
        eigenvalue, featurevector = np.linalg.eig(np.matrix(self.matrix).T)
        bigeigvalue=np.sort(np.real(eigenvalue))[-5:]
        self.bigeig=bigeigvalue
        eigindex = np.where(np.real(eigenvalue)>0.98)[0]
        self.eigvalue=eigenvalue[eigindex]
        if(len(eigindex)==1):
            eig=eigindex[0]
            timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
            timeprob = np.array(timeprob).flatten()
            self.timeprob=[timeprob]
            return self.timeprob,1
        if(len(eigindex)==2):
            qualifiedid=[]
            solution=[]
            for i in range(0,2):
                eig=eigindex[i]
                timeprob = np.real(featurevector[:, eig] / np.sum(featurevector[:, eig]))
                timeprob = np.array(timeprob).flatten()
                if(np.sum(timeprob)/np.sum(abs(timeprob))>0.999):
                    qualifiedid.append(i)
                    solution.append(timeprob)
            if(len(qualifiedid)==2):
                self.timeprob=solution
                return self.timeprob,2
            else:
                unqindex=np.setdiff1d(np.arange(0,2),np.array(qualifiedid))[0]
                eig=eigindex[unqindex]
                timeprob = abs(np.real(featurevector[:, eig]))
                timeprob = np.array(timeprob).flatten()
                alpha = timeprob / np.sum(timeprob)
                fixalpha = solution[0]
                leftrange = -50
                rightrange = 50
                k = np.linspace(leftrange, rightrange, int(np.round((rightrange - leftrange) / 0.0001)))
                targetsum=1
                for i in range(0, len(k)):
                    k0 = k[i]
                    k1 = 1-k0
                    probnew = k0*alpha+k1*fixalpha
                    targetcompare = np.dot(fixalpha,abs(probnew))
                    if (targetcompare < targetsum):
                        targetk = k0
                        targetsum = targetcompare
                k0 = targetk
                k1 = 1 - k0
                solution.append(k0 * alpha + k1 * fixalpha)
                self.timeprob = solution
                return self.timeprob,2

        
            k0test=65
            k1test=1-k0test
            leftrange=1
            rightrange=65
            while(rightrange-leftrange>0.001):
                if(sum(k0test*alpha[0]+k1test*alpha[1])/sum(abs(k0test*alpha[0]+k1test*alpha[1]))<0.999):
                    rightrange=k0test
                    k0test=(k0test+leftrange)/2
                else:
                    leftrange=k0test
                    k0test=(k0test+rightrange)/2
            leftrange=-50
            rightrange=50
            k0=np.linspace(leftrange,rightrange,int(np.round((rightrange-leftrange)/0.0001)))
            targetk=0
            targetsum=1
            for i in range(0,len(k0)):
                k0p=k0[i]
                k1p=1-k0p
                bb=k0p*np.dot(alpha[0],alpha[0])+k1p*np.dot(alpha[0],alpha[1])
                aa=k1p*np.dot(alpha[1],alpha[1])+k0p*np.dot(alpha[0],alpha[1])
                k0s=bb/(bb-aa)
                k1s=aa/(aa-bb)
                alphap=k0p*alpha[0]+k1p*alpha[1]
                alphas=k0s*alpha[0]+k1s*alpha[1]
                targetcompare=np.sum(abs(alphap*alphas))
                if(targetcompare<targetsum):
                    targetk=k0[i]
                    targetsum=targetcompare
            solution=[]
            k0p=k0[i]
            k1p=1-k0p
            bb=k0p*np.dot(alpha[0],alpha[0])+k1p*np.dot(alpha[0],alpha[1])
            aa=k1p*np.dot(alpha[1],alpha[1])+k0p*np.dot(alpha[0],alpha[1])
            k0s=bb/(bb-aa)
            k1s=aa/(aa-bb)
            alphap=k0p*alpha[0]+k1p*alpha[1]
            alphas=k0s*alpha[0]+k1s*alpha[1]
            solution.append(alphap)
            solution.append(alphas)
            self.timeprob=solution
            return solution,2
        '''

    def ampprobcalculate(self):
        print('calculating ampprob')
        self.ampprob_up = []
        self.bestsigma=[]
        for i in range(0, self.num):
            if (self.combo[i] == 1):
                bestsigma = np.sqrt(self.xsquare[i] / self.samplength[i])
                self.bestsigma.append(bestsigma)
                p=0.5+0.5*sympy.erf(self.Apeak[i][0] / sympy.sqrt(2) / bestsigma).evalf(100)
                self.ampprob_up.append(p)
            else:
                ampprob_up = []
                sigma = []
                for j in range(0, self.combo[i]):
                    bestsigma = np.sqrt(self.xsquare[i][j] / self.samplength[i][j])
                    p = 0.5 + 0.5*sympy.erf(self.Apeak[i][j] / sympy.sqrt(2) / bestsigma).evalf(100)
                    ampprob_up.append(p)
                    sigma.append(bestsigma)
                self.ampprob_up.append(sum(ampprob_up) / len(ampprob_up))
                self.bestsigma.append(sigma)
            if (self.ampprob_up[i] > 1):
                self.ampprob_up[i] = 1
        return np.array(self.ampprob_up)

    def estimation(self,qualifiedid):
        timeprob=self.timeprob[qualifiedid]
        self.polarityestimation=np.sum(timeprob*self.ampprob_up)
        unknownindex=np.where(np.array(self.Apeak)==0)[0]
        knownindex=np.setdiff1d(np.arange(0,self.num),unknownindex)
        self.polarityunknown = np.sum(timeprob[unknownindex])
        self.polarityup=np.sum(timeprob[knownindex]*np.array(self.ampprob_up)[knownindex])
        self.polaritydown=1-self.polarityup-self.polarityunknown
        Apeakestimate=np.zeros(self.num)
        arrivalestimate=np.zeros(self.num)
        sigmaestimate=np.zeros(self.num)
        for i in range(0,self.num):
            Apeakestimate[i]=np.sum(self.Apeak[i])/self.combo[i]
            arrivalestimate[i] = np.sum(self.arrivaltimestamp[i]) / self.combo[i]
            sigmaestimate[i]=np.sum(self.bestsigma[i]) / self.combo[i]
        self.Apeakestimate=np.sum(timeprob * Apeakestimate)
        self.arrivalestimate=np.sum(timeprob * arrivalestimate)
        self.sigmaestimate=np.sum(timeprob * sigmaestimate)

    def timeprobinterpolate(self):
        print('coming soon')

    def getstateinform(self, stateid):
        if (stateid >= self.num):
            print('wrong stateid')
            return -1, -1, -1, -1, -1
        else:
            return self.combo[stateid],self.downthreshold[stateid], self.upthreshold[stateid] ,self.sample[stateid], self.pmi[stateid], \
                   self.Apeak[stateid]

    def getstateprob(self,qualifiedid,stateid):
        if (stateid >= self.num):
            print('wrong stateid')
            return -1, -1
        else:
            return self.timeprob[qualifiedid][stateid], self.ampprob_up[stateid]
