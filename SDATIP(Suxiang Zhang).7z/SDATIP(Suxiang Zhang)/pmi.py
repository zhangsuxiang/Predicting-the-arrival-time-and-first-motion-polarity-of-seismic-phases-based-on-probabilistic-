#allentropy.py
import numpy as np

def Entropy(ampen2):
    zeronum=len(np.where(ampen2==0)[0])
    onenum=len(np.where(ampen2==1)[0])
    if(zeronum==0 or onenum==0):return 0
    length2=len(ampen2)
    pzero=zeronum/length2
    pone=onenum/length2
    en=np.log2(pzero)*pzero+np.log2(pone)*pone
    return -en

def pmi(ampbi,t):
    lengthall=len(ampbi)
    zeronum0=len(np.where(ampbi[0:t]==0)[0])
    zeronum1=len(np.where(ampbi[0:t]==1)[0])
    onenum0=len(np.where(ampbi[t:]==0)[0])
    onenum1=len(np.where(ampbi[t:]==1)[0])
    pmi=np.zeros([2,2])
    npmi=np.zeros([2,2])
    if(zeronum0==0):
        pmi[0,0]=0
        npmi[0,0]=-1
    else:
        pmi[0,0]=zeronum0/lengthall*np.log2(zeronum0*lengthall/(zeronum0+zeronum1)/(zeronum0+onenum0))
        npmi[0,0]=(-1)*np.log2(zeronum0*lengthall/(zeronum0+zeronum1)/(zeronum0+onenum0))/np.log2(zeronum0/lengthall)
    if(zeronum1==0):
        pmi[0,1]=0
        npmi[0,1]=-1
    else:
        pmi[0,1]=zeronum1/lengthall*np.log2(zeronum1*lengthall/(zeronum0+zeronum1)/(zeronum1+onenum1))
        npmi[0,1]=(-1)*np.log2(zeronum1*lengthall/(zeronum0+zeronum1)/(zeronum1+onenum1))/np.log2(zeronum1/lengthall)
    if(onenum0==0):
        pmi[1,0]=0
        npmi[1,0]=-1
    else:
        pmi[1,0]=onenum0/lengthall*np.log2(onenum0*lengthall/(onenum0+onenum1)/(zeronum0+onenum0))
        npmi[1,0]=(-1)*np.log2(onenum0*lengthall/(onenum0+onenum1)/(zeronum0+onenum0))/np.log2(onenum0/lengthall)
    if(onenum1==0):
        pmi[1,1]=0
        npmi[1,1]=-1
    else:
        pmi[1,1]=onenum1/lengthall*np.log2(onenum1*lengthall/(onenum0+onenum1)/(zeronum1+onenum1))
        npmi[1,1]=(-1)*np.log2(onenum1*lengthall/(onenum0+onenum1)/(zeronum1+onenum1))/np.log2(onenum1/lengthall)
    mivalue=np.sum(np.sum(pmi))
    qmivalue=pmi[0,0]-pmi[0,1]-pmi[1,0]+pmi[1,1]
    npmivalue=npmi[0,0]-npmi[0,1]-npmi[1,0]+npmi[1,1]
    enpmivalue=npmi[0,0]*zeronum0/lengthall-npmi[0,1]*zeronum1/lengthall-npmi[1,0]*onenum0/lengthall+npmi[1,1]*onenum1/lengthall
    #print(pmi[0,0],pmi[0,1],pmi[1,0],pmi[1,1],npmi[0,0],npmi[0,1],npmi[1,0],npmi[1,1],npmi[0,0]*zeronum0/lengthall,npmi[0,1]*zeronum1/lengthall,npmi[1,0]*onenum0/lengthall,npmi[1,1]*onenum1/lengthall)
    return mivalue,enpmivalue
    
def maxpmi(ampbi,n):
    zeronum=len(np.where(ampbi==0)[0])
    onenum=len(np.where(ampbi==1)[0])
    if(zeronum==0 or onenum==0):
        return -1,-1,-1
    if(n!=-1):
        return pmi(ampbi,n),n
    else:
        result=np.zeros([len(ampbi)-1,2])
        readyindex=np.where(ampbi[1:]-ampbi[0:-1]==1)[0]
        #print()
        for i in range(0,len(readyindex)):
            result[readyindex[i]]=pmi(ampbi,readyindex[i]+1)
    t_num=np.where(result[:,1]==np.max(result[:,1]))[0]
    #print(np.max(result[:,1]),result[:,1])
    t_num = np.where(result[:, 0] == np.max(result[:, 0]))[0]
    return result[t_num, 0], result[t_num, 1], t_num+1

def calculategeneral(xsquare,n):
    if(n==3):return 1/xsquare
    if(n==2):return np.sqrt(np.pi/2/xsquare)
    if(np.mod(n,2)==1):
        m=(n-3)/2
        lt=range(2,n-1,2)
        return reduce(lambda x,y:x*y,lt)*(1/xsquare)**(m+1)
    if(np.mod(n,2)==0):
        m=(n-2)/2
        lt=range(1,n-2,2)
        return reduce(lambda x,y:x*y,lt)*np.sqrt(np.pi/2/xsquare)*(1/xsquare)**(m)
