import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plotprob(a, b, qualifiedid, name, outputdir):
    fig = plt.figure(figsize=(20, 12))
    plt.rcParams["font.weight"] = "normal"
    plt.rcParams["axes.labelweight"] = "normal"
    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams["font.size"] = 45

    timeprob = b.timeprob[qualifiedid]
    ax1 = fig.add_axes([0.47, 0.33, 0.45, 0.6])
    ax1.plot(a.longtimestamp, a.denselongdata,
             linewidth=5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp, abs(a.denselongdata),
             linewidth=5, color='k', linestyle=':', alpha=0.9)

    # 调整阈值
    b.upthreshold[-1] = b.upthreshold[-2] * 1.5

    colori = np.zeros([a.length, 3])
    prob1 = timeprob / (np.array(b.upthreshold) - np.array(b.downthreshold))
    alphacoefficient = 0.75 / np.max(prob1)

    downt = np.zeros(b.num)
    upt = np.zeros(b.num)
    downt1 = np.zeros(b.num)
    upt1 = np.zeros(b.num)
    oritprob = np.zeros(a.length)
    tprobid = np.zeros(b.num)

    # 计算累积时间概率段
    for i in range(b.num):
        tprobid[i] = int(np.floor(a.longtimestamp[a.cut[i]] / a.delta))
        oritprob[int(tprobid[i])] += timeprob[i]
        if abs(b.Apeak[i][0]) > 0:
            downt1[i] = a.timestamp[int(tprobid[i])]
            upt1[i] = a.timestamp[int(tprobid[i]) + 1]
        else:
            downt1[i] = a.timestamp[-1]
            upt1[i] = a.timestamp[-1] + 0.1 * a.timestamp[-1]

    # 填色主图区域
    for i in range(b.num):
        if b.Apeak[i][0] > 0:
            colori[i, :] = [1, 0, 0]
        elif b.Apeak[i][0] < 0:
            colori[i, :] = [0, 0, 1]

        if abs(b.Apeak[i][0]) > 0:
            tchange = a.longtimestamp[a.cut[i] + 1] - a.longtimestamp[a.cut[i]]
            achange = a.denselongdata[a.cut[i] + 1] - a.denselongdata[a.cut[i]]
            downt[i] = tchange / achange * (b.downthreshold[i] - abs(a.denselongdata[a.cut[i]])) + a.longtimestamp[a.cut[i]]
            upt[i] = tchange / achange * (b.upthreshold[i] - abs(a.denselongdata[a.cut[i]])) + a.longtimestamp[a.cut[i]]

            ax1.fill_between(
                [0, downt[i], upt[i]],
                [b.downthreshold[i]] * 3,
                [b.upthreshold[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )
            ax1.fill_betweenx(
                [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                [downt[i]] * 3,
                [upt[i]] * 3,
                color=colori[i, :],
                alpha=timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )
        else:
            downt[i] = a.longtimestamp[-1]
            upt[i] = a.longtimestamp[-1] + 0.1 * a.timestamp[-1]
            ax1.fill_between(
                [0, downt[i], upt[i]],
                [b.downthreshold[i]] * 3,
                [b.upthreshold[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )
            ax1.fill_betweenx(
                [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                [downt[i]] * 3,
                [upt[i]] * 3,
                color=colori[i, :],
                alpha=timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )

    # 主图坐标轴与刻度
    ax1.set(xlim=(0, np.max(a.densetimestamp) + 0.1 * a.timestamp[-1]),
            ylim=(-b.upthreshold[-2], b.upthreshold[-1]))
    ax1.yaxis.tick_right()
    ax1.tick_params(direction='out', size=20, length=5, width=2)
    ax1.set_yticks([-b.upthreshold[-2], 0, b.upthreshold[-1]])
    ax1.set_yticklabels(
        ['%.1f' % (-b.upthreshold[-2] / 10000), '0.0', '%.1f' % (b.upthreshold[-1] / 10000)],
        fontweight='normal', fontsize=45, fontname="Times New Roman"
    )
    ax1.set_xticks(np.linspace(0, a.timestamp[-1], 5))
    ax1.set_xticklabels(
        ['%.2f' % val for val in np.linspace(0, a.timestamp[-1], 5)],
        fontweight='normal', fontsize=25, fontname="Times New Roman"
    )
    [t.set_color('white') for t in ax1.xaxis.get_ticklabels()]
    for spine in ax1.spines.values():
        spine.set_linewidth(5)

    # 子图2：概率分布
    ax2 = fig.add_axes([
        0.11,
        0.93 - 0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1],
        0.25,
        0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1]
    ])
    ax2.invert_xaxis()
    for i in range(b.num):
        ax2.fill_betweenx(
            [b.downthreshold[i], b.upthreshold[i]], 0, prob1[i], color=colori[i, :], alpha=1
        )
    ax2.set(ylim=(-4000, b.upthreshold[-1]))
    ax2.set_xticks(np.linspace(0, np.max(prob1), 3))
    ax2.set_xticklabels(
        ['%d' % 0, '%.2f' % (np.max(prob1) / 4 * 2 * 70), '%.2f' % (np.max(prob1) * 70)],
        fontweight='normal', fontsize=45
    )
    ax2.set_yticks(np.linspace(0, b.upthreshold[-1], 3))
    ax2.set_yticklabels(
        ['%.1f' % 0, '%.1f' % (b.upthreshold[-1] / 4 * 2 / 10000), '%.1f' % (b.upthreshold[-1] / 10000)],
        fontsize=45
    )
    ax2.tick_params(direction='out', size=20, length=5, width=2)
    ax2.set_ylabel(r'$\epsilon$', fontsize=45)
    ax2.set_xlabel('PDF', weight='normal', fontsize=45, fontname="Times New Roman")
    for spine in ax2.spines.values():
        spine.set_linewidth(5)

    # 子图3：时间概率累积
    ax3 = fig.add_axes([0.47, 0.13, 0.45, 0.12])
    for i in range(b.num):
        ax3.fill_between(
            [downt1[i], upt1[i]],
            [0, 0], [oritprob[int(tprobid[i])]] * 2,
            color=colori[i, :], alpha=1
        )
    ax3.plot([b.arrivalestimate, b.arrivalestimate],
             [0, np.max(oritprob) * 1.1], linewidth=3, color='k', linestyle=':', alpha=0.9)
    ax3.yaxis.tick_right()
    ax3.set(xlim=(0, np.max(a.densetimestamp) + 0.1 * a.timestamp[-1]), ylim=(0, np.max(oritprob) * 1.1))
    ax3.set_yticks(np.linspace(0, np.max(oritprob), 3))
    ax3.set_yticklabels(
        ['%d' % 0, '%d' % (100 * np.max(oritprob) / 2), '%d' % (100 * np.max(oritprob))],
        fontweight='normal', fontsize=45
    )
    ax3.set_xticks(np.linspace(0, a.timestamp[-1], 5))
    ax3.set_xticklabels(
        ['%.2f' % val for val in np.linspace(0, a.timestamp[-1], 5)], fontsize=45
    )
    ax3.tick_params(direction='out', size=20, length=5, width=1)
    ax3.set_ylabel('PDF', fontsize=45)
    ax3.set_xlabel('Time (s)', weight='normal', fontsize=45, fontname="Times New Roman")
    for spine in ax3.spines.values():
        spine.set_linewidth(5)

    # 子图4：极性统计
    ax4 = fig.add_axes([0.125, 0.12, 0.225, 0.05])
    y = [1, 1, 1]
    width = [float(b.polarityup), float(b.polarityunknown), float(b.polaritydown)]
    leftcoord = [0, float(b.polarityup), float(b.polarityup + b.polarityunknown)]
    colors = [[1, 0, 0], [0.7, 0.7, 0.7], [0, 0, 1]]
    labels = ['Up', 'Unknown', 'Down']
    for i in range(3):
        ax4.barh(y[i], width[i], height=1, left=leftcoord[i], color=colors[i], label=labels[i])
    ax4.set_xticks([0.5])
    ax4.set_xticklabels(['0.5'], fontweight='normal', fontsize=45)
    ax4.text(-0.07, 2, 'U:%.1f%%' % (abs(float(b.polarityup)) * 100), fontsize=45)
    ax4.text(0.7, 2, 'D:%.1f%%' % (abs(float(b.polaritydown)) * 100), fontsize=45)
    ax4.text(-0.37, 2, 'Pol:', fontweight='normal', fontsize=45, fontname="Times New Roman")
    ax4.set_yticks([])
    ax4.set(xlim=(0, 1), ylim=(0.5, 1.5))
    ax4.plot([0.5, 0.5], [0, 1.5], linewidth=5, color='k', linestyle=':', alpha=1)
    for spine in ax4.spines.values():
        spine.set_linewidth(5)

    # 图注信息
    fig.text(0.04, 0.305,
             'E.V.: %d, %d, %.2f, ...' % (b.bigeig[0], b.bigeig[1], b.bigeig[2]),
             fontweight='normal', fontsize=45, fontname="Times New Roman")

    # 保存图片
    fig.savefig(f'{outputdir}{name}_{qualifiedid}.png', dpi=1300)
    fig.savefig(f'{outputdir}{name}.eps', dpi=1300, transparent=False)
    fig.savefig(f'{outputdir}{name}_{qualifiedid}.pdf')