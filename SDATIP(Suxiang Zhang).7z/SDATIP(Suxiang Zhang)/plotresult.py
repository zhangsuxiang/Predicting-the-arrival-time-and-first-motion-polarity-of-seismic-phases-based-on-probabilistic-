import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def plotprob(a, b, qualifiedid, name, outputdir):
    fig = plt.figure(figsize=(25, 9))
    plt.rcParams["font.weight"] = "bold"
    plt.rcParams["axes.labelweight"] = "bold"

    timeprob = b.timeprob[qualifiedid]
    ax1 = fig.add_axes([0.4, 0.33, 0.55, 0.6])
    ax1.plot(a.longtimestamp, a.denselongdata,
             linewidth=2.5, color='k', linestyle='-')
    ax1.plot(a.longtimestamp, abs(a.denselongdata),
             linewidth=2.5, color='k', linestyle=':', alpha=0.9)

    # 调整阈值
    b.upthreshold[-1] = b.upthreshold[-2] * 1.5

    # 准备绘图所需数据
    colori = np.zeros([b.num, 3])
    prob1 = timeprob / (np.array(b.upthreshold) - np.array(b.downthreshold))
    alphacoefficient = (0.75 - 0.03) / np.max(prob1)
    downt = np.zeros(b.num)
    upt = np.zeros(b.num)

    for i in range(b.num):
        if b.Apeak[i][0] > 0:
            colori[i, :] = [1, 0, 0]
        elif b.Apeak[i][0] < 0:
            colori[i, :] = [0, 1, 0]

        if abs(b.Apeak[i][0]) > 0:
            dt = a.longtimestamp[a.cut[i] + 1] - a.longtimestamp[a.cut[i]]
            da = a.denselongdata[a.cut[i] + 1] - a.denselongdata[a.cut[i]]
            downt[i] = dt / da * (b.downthreshold[i] - abs(a.denselongdata[a.cut[i]])) + a.longtimestamp[a.cut[i]]
            upt[i] = dt / da * (b.upthreshold[i] - abs(a.denselongdata[a.cut[i]])) + a.longtimestamp[a.cut[i]]

            # 画竖线和横线
            for x, thr in [(downt[i], b.downthreshold[i]), (upt[i], b.upthreshold[i])]:
                ax1.plot([x, x], [thr, -b.upthreshold[-1]],
                         linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                ax1.plot([0, x], [thr, thr],
                         linewidth=0.001, color='k', linestyle='--', alpha=0.3)

            # 填充区域
            ax1.fill_between(
                [0, downt[i], upt[i]],
                [b.downthreshold[i]] * 3,
                [b.upthreshold[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )
            ax1.fill_betweenx(
                [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                [downt[i]] * 3,
                [upt[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )

        else:
            # Apeak == 0 时的处理
            downt[i] = a.longtimestamp[-1]
            upt[i] = a.longtimestamp[-1] + 0.1 * a.timestamp[-1]
            for x, thr in [(downt[i], b.downthreshold[i]), (upt[i], b.upthreshold[i])]:
                ax1.plot([x, x], [thr, -b.upthreshold[-1]],
                         linewidth=0.001, color='k', linestyle='--', alpha=0.3)
                ax1.plot([0, x], [thr, thr],
                         linewidth=0.001, color='k', linestyle='--', alpha=0.3)
            ax1.fill_between(
                [0, downt[i], upt[i]],
                [b.downthreshold[i]] * 3,
                [b.upthreshold[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )
            ax1.fill_betweenx(
                [-b.upthreshold[-2], b.downthreshold[i], b.upthreshold[i]],
                [downt[i]] * 3,
                [upt[i]] * 3,
                color=colori[i, :],
                alpha=0.03 + timeprob[i] / (b.upthreshold[i] - b.downthreshold[i]) * alphacoefficient
            )

    # 坐标轴范围与刻度
    ax1.set(xlim=(0, np.max(a.densetimestamp) + 0.1 * a.timestamp[-1]),
            ylim=(-b.upthreshold[-2], b.upthreshold[-1]))
    ax1.tick_params(direction='out', size=20)

    ax1.set_yticks([-b.upthreshold[-2], 0, b.upthreshold[-1]])
    ax1.set_yticklabels(
        ['%.2f' % (-b.upthreshold[-2]), '0.00', '%.2f' % b.upthreshold[-1]],
        fontweight='bold'
    )

    ax1.set_xticks(np.linspace(0, a.timestamp[-1], 5))
    ax1.set_xticklabels(
        ['%.2f' % val for val in np.linspace(0, a.timestamp[-1], 5)],
        fontweight='bold'
    )

    for spine in ax1.spines.values():
        spine.set_linewidth(2)

    # 第二个子图：概率条形图
    ax2 = fig.add_axes([
        0.1,
        0.93 - 0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1],
        0.25,
        0.6 / (b.upthreshold[-1] + b.upthreshold[-2]) * b.upthreshold[-1]
    ])
    ax2.invert_xaxis()
    for i in range(b.num):
        ax2.fill_betweenx(
            [b.downthreshold[i], b.upthreshold[i]],
            0, prob1[i],
            color=colori[i, :],
            alpha=1
        )
        ax2.plot([0, prob1[i]], [b.upthreshold[i]] * 2,
                 linewidth=0.001, color='k', linestyle='--')
        ax2.plot([0, prob1[i]], [b.downthreshold[i]] * 2,
                 linewidth=0.001, color='k', linestyle='--')

    ax2.set(ylim=(0, b.upthreshold[-1]))
    ax2.set_xticks(np.linspace(0, np.max(prob1), 5))
    ax2.set_xticklabels(
        ['%.2f' % val for val in np.linspace(0, np.max(prob1), 5)],
        fontweight='bold'
    )
    ax2.set_yticks(np.linspace(0, b.upthreshold[-1], 5))
    ax2.set_yticklabels(
        ['%.2f' % val for val in np.linspace(0, b.upthreshold[-1], 5)],
        fontweight='bold'
    )
    ax2.tick_params(direction='out', size=20)
    ax2.set_ylabel(r'$\mathbf{\varepsilon_{threshold}}$', weight='bold')
    ax2.set_xlabel(r'PDF of $\mathbf{\varepsilon_{threshold}}$', weight='bold')
    for spine in ax2.spines.values():
        spine.set_linewidth(2)

    # 第三个子图：时间概率分布
    ax3 = fig.add_axes([0.4, 0.1, 0.55, 0.15], sharex=ax1)
    for i in range(b.num):
        ax3.plot([downt[i], downt[i]],
                 [0, np.max(prob1) * 1.1],
                 linewidth=0.001, color='k', linestyle='-', alpha=0.3)
        ax3.plot([upt[i], upt[i]],
                 [0, np.max(prob1) * 1.1],
                 linewidth=0.001, color='k', linestyle='-', alpha=0.3)
        ax3.plot([downt[i], upt[i]],
                 [prob1[i]] * 2,
                 linewidth=0.001, color='k', linestyle='-', alpha=0.3)
        ax3.fill_between(
            [downt[i], upt[i]],
            [0, 0],
            [prob1[i]] * 2,
            color=colori[i, :],
            alpha=1
        )
    ax3.plot([b.arrivalestimate] * 2,
             [0, np.max(prob1) * 1.1],
             linewidth=2.3, color='k', linestyle=':', alpha=0.9)

    ax3.set(ylim=(0, np.max(prob1) * 1.1))
    ax3.set_yticks(np.linspace(0, np.max(prob1), 3))
    ax3.set_yticklabels(
        ['%.2f' % val for val in np.linspace(0, np.max(prob1), 3)],
        fontweight='bold'
    )
    ax3.set_xticks(np.linspace(0, a.timestamp[-1], 5))
    ax3.set_xticklabels(
        ['%.2f' % val for val in np.linspace(0, a.timestamp[-1], 5)],
        fontweight='bold'
    )
    ax3.tick_params(direction='out', size=20)
    ax3.set_ylabel('PDF of Time', weight='bold')
    ax3.set_xlabel('Time/s', weight='bold')
    for spine in ax3.spines.values():
        spine.set_linewidth(2)

    # 第四个子图：极性统计
    ax4 = fig.add_axes([0.1, 0.13, 0.23, 0.05])
    y = [1, 1, 1]
    width = [float(b.polarityup), float(b.polarityunknown), float(b.polaritydown)]
    leftcoord = [0,
                 float(b.polarityup),
                 float(b.polarityup + b.polarityunknown)]
    colors = [[1, 0, 0], [0.7, 0.7, 0.7], [0, 1, 0]]
    labels = ['Up', 'Unknown', 'Down']
    for i in range(3):
        ax4.barh(y[i], width[i], height=1,
                 left=leftcoord[i], color=colors[i], label=labels[i])

    ax4.set_xticks([0.5])
    ax4.set_xticklabels(['0.5'], fontweight='bold')
    ax4.text(0, 2, 'Up:%.1f%%' % (float(b.polarityup) * 100))
    ax4.text(0.85, 2, 'Down:%.1f%%' % (float(b.polaritydown) * 100))
    ax4.set_yticks([])
    ax4.set(xlim=(0, 1), ylim=(0.5, 1.5))
    ax4.plot([0.5, 0.5], [0, 1.5],
             linewidth=2.5, color='k', linestyle=':', alpha=1)
    ax4.legend(ncol=3, loc='lower center', bbox_to_anchor=(0.5, 1.5))
    for spine in ax4.spines.values():
        spine.set_linewidth(2)

    # 添加标题和统计信息
    fig.text(0.21, 0.38, name,
             {'fontweight': 'bold', 'fontsize': 25},
             horizontalalignment='center')
    fig.text(0.24, 0.33,
             r'$\mathbf{A_{peak}}$: %.3f' % b.Apeakestimate,
             {'fontweight': 'bold', 'fontsize': 15})
    fig.text(0.24, 0.28,
             r'$\mathbf{\sigma}$: %.3f' % b.sigmaestimate,
             {'fontweight': 'bold', 'fontsize': 15})
    fig.text(0.1, 0.33,
             'Arrivaltime: %.3f' % b.arrivalestimate,
             {'fontweight': 'bold', 'fontsize': 15})
    fig.text(0.1, 0.28,
             'Polarity Up: %.3f' % b.polarityestimation,
             {'fontweight': 'bold', 'fontsize': 15})
    fig.text(0.1, 0.23,
             'Eig value: %s' % b.bigeig)

    # 保存图像
    fig.savefig(f'{outputdir}{name}_{qualifiedid}.png', dpi=1300)
    fig.savefig(f'{outputdir}{name}_{qualifiedid}.pdf')