# Waveform.py
import numpy as np
import obspy
from scipy.signal import argrelextrema
import pmi
import State


class Waveform():
    def __init__(self,name):
        self.name=name
        self.num = 1

    def importdata(self, data, delta):
        self.data = data
        self.delta = delta
        self.length = len(self.data)
        self.timestamp=np.linspace(0,self.delta*(self.length-1),self.length)

    def importdatafromsac(self, filename):
        a=obspy.read('%s'%(filename))
        self.data=a[0].data
        self.delta=a[0].stats.delta
        self.length=len(self.data)
        self.timestamp = np.linspace(0, self.delta * (self.length - 1), self.length)

    def analyzedata(self):
        self.mean = np.mean(self.data)
        self.median = np.median(self.data)
        self.extrememax = argrelextrema(self.data, np.greater_equal)[0]
        self.extrememin = argrelextrema(-1 * self.data, np.greater_equal)[0]
        self.extremeall = np.sort(np.append(self.extrememax, self.extrememin))
        self.above0 = len(np.where(self.data > 0)[0])
        self.below0 = len(np.where(self.data < 0)[0])

    def rmmean(self):
        self.data = self.data - self.mean
        self.above0 = len(np.where(self.data > 0)[0])
        self.below0 = len(np.where(self.data < 0)[0])

    def rmtail(self):
        self.data = self.data[0:self.extremeall[-2] + 1]
        self.extremeall = self.extremeall[0:-1]
        self.length = len(self.data)
        self.extrememax = argrelextrema(self.data, np.greater_equal)[0]
        self.extrememin = argrelextrema(-1 * self.data, np.greater_equal)[0]
        self.above0 = len(np.where(self.data > 0)[0])
        self.below0 = len(np.where(self.data < 0)[0])

    def interpolate(self,coefficient):
        self.densedelta=self.delta/coefficient
        self.denselength=self.length+(self.length-1)*(coefficient-1)
        self.densetimestamp=np.linspace(0, self.densedelta * (self.denselength - 1), self.denselength)
        self.densedata=np.interp(self.densetimestamp, self.timestamp, self.data)
        self.denseextrememax = argrelextrema(self.densedata, np.greater_equal)[0]
        self.denseextrememin = argrelextrema(-1 * self.densedata, np.greater_equal)[0]
        self.denseextremeall = np.unique(np.append(self.denseextrememax, self.denseextrememin))
        self.denseco=coefficient
        self.dataindexindense=np.arange(0,self.denselength-1+self.denseco,self.denseco)

    def denseunique(self):
        self.dense_abs = abs(self.densedata)
        self.dense_abs_unique = np.unique(self.dense_abs)
        dense_abs_unique_index = []
        for i in range(0, len(self.dense_abs_unique)):
            dense_abs_unique_index.append(np.where(self.dense_abs == self.dense_abs_unique[i])[0])
        self.dense_abs_unique_index = dense_abs_unique_index
        self.threshold = self.dense_abs_unique

    def denselong(self,hvcoefficient,mininsertco):
        hunit=hvcoefficient*(max(self.data)-min(self.data))/(self.length-1)
        vchange = abs(self.data[1:] - self.data[0:-1])
        self.longtimestamp=np.array([])
        self.dataindexinlong=np.array([])
        for i in range(0,self.length-1):
            insertpointnumber=int(np.round(np.sqrt(vchange[i]**2+hunit**2)*mininsertco/hunit))
            insertvector = np.linspace(self.timestamp[i], self.timestamp[i + 1], insertpointnumber + 1)
            if(i<self.length-2):
                self.dataindexinlong=np.append(self.dataindexinlong,len(self.longtimestamp))
                self.longtimestamp=np.append(self.longtimestamp,insertvector[0:-1])
            else:
                self.dataindexinlong = np.append(self.dataindexinlong, len(self.longtimestamp))
                self.longtimestamp=np.append(self.longtimestamp, insertvector)
                self.dataindexinlong = np.append(self.dataindexinlong, len(self.longtimestamp)-1)
        self.denselongdata=np.interp(self.longtimestamp, self.timestamp, self.data)
        self.denselongabs=abs(self.denselongdata)
        self.longlength=len(self.denselongdata)
        self.longextrememax = argrelextrema(self.denselongdata, np.greater_equal)[0]
        self.longextrememin = argrelextrema(-1 * self.denselongdata, np.greater_equal)[0]
        self.longextremeall = np.unique(np.append(self.longextrememax, self.longextrememin))
        self.hvcoefficient=hvcoefficient
        self.mininsertco=mininsertco

# use maximum near extreme point
    def extremearr(self):
        self.longextremearr=np.zeros(self.longlength)
        for i in range(1, len(self.longextremeall)):
            if (self.denselongabs[self.longextremeall[i]] >= self.denselongabs[self.longextremeall[i - 1]]):
                self.longextremearr[self.longextremeall[i - 1]:self.longextremeall[i] + 1] = self.denselongabs[self.longextremeall[i]]
            if (self.denselongabs[self.longextremeall[i]] < self.denselongabs[self.longextremeall[i - 1]]):
                self.longextremearr[self.longextremeall[i - 1]:self.longextremeall[i] + 1] = self.denselongabs[self.longextremeall[i - 1]]
        self.longextremearrmin=np.min(self.longextremearr)

# use like sign maximum near extreme point
    def extremearr(self):
        self.longextremearr=np.zeros(self.longlength)
        for i in range(1, len(self.longextremeall)):
            if (self.denselongdata[self.longextremeall[i]] * self.denselongdata[self.longextremeall[i - 1]] > 0):
                if (self.denselongabs[self.longextremeall[i]] >= self.denselongabs[self.longextremeall[i - 1]]):
                    self.longextremearr[self.longextremeall[i - 1]:self.longextremeall[i] + 1] = self.denselongabs[self.longextremeall[i]]
                if (self.denselongabs[self.longextremeall[i]] < self.denselongabs[self.longextremeall[i - 1]]):
                    self.longextremearr[self.longextremeall[i - 1]:self.longextremeall[i] + 1] = self.denselongabs[self.longextremeall[i - 1]]
            else:
                signarray=self.denselongdata[self.longextremeall[i - 1]:self.longextremeall[i]]*self.denselongdata[self.longextremeall[i - 1]+1:self.longextremeall[i]+1]
                turnpoint=np.where(signarray<=0)[0][0]+1
                self.longextremearr[self.longextremeall[i - 1]:self.longextremeall[i - 1]+turnpoint]=self.denselongabs[self.longextremeall[i - 1]]
                self.longextremearr[self.longextremeall[i - 1] + turnpoint:self.longextremeall[i]+1] = self.denselongabs[self.longextremeall[i]]
        self.longextremearrmin=np.min(self.longextremearr)
    '''
    def extremearr(self):
        self.longextremearr=np.zeros(self.longlength)
        for i in range(0,len(self.longextremeall)-1):
            self.longextremearr[self.longextremeall[i]:self.longextremeall[i+1]]=self.denselongabs[self.longextremeall[i+1]]
        self.longextremearr[-1]=self.longextremearr[-2]
        self.longextremearrmin=np.min(self.longextremearr)
    '''

    def densebin(self):
        #longarray = np.ones(self.longlength+ int(np.round(self.longlength*0.0015)))
        longarray = np.ones(self.longlength+1)
        self.mivalue = np.zeros(len(self.dense_abs_unique))
        self.pmivalue = np.zeros(len(self.dense_abs_unique))
        self.mivalue=[]
        self.pmivalue=[]
        self.cut = []
        self.peak = []
        self.noiselength = []
        self.noiseindex = []
        self.chances=[]
        for i in range(0,len(self.threshold)):
            #longarray = np.ones(self.longlength + int(np.round(self.longlength * 0.0015)))
            longarray = np.ones(self.longlength+1)
            if(self.threshold[i]>self.longextremearrmin):
                zeroindex=np.where(abs(self.longextremearr)<=self.threshold[i])[0]
                longarray[zeroindex] = 0
                [mivalue, pmivalue, longcutsolution] = pmi.maxpmi(longarray, -1)
                for j in range(0, len(longcutsolution)):
                    if (longcutsolution[j] < self.longlength):
                        longcutsolution[j]=longcutsolution[j]+1
                        cutincycle=int(np.where(self.denselongabs[longcutsolution[j]:]>self.threshold[i])[0][0])
                        longcutsolution[j]=longcutsolution[j]+cutincycle
            else:
                zeroindex=np.where(abs(self.denselongdata)<=self.threshold[i])[0]
                longarray[zeroindex] = 0
                [mivalue,pmivalue,longcutsolution]=pmi.maxpmi(longarray, -1)
            zeroindex=np.where(abs(self.denselongdata)<=self.threshold[i])[0]
            if(len(zeroindex)>0.95*self.longlength):
                [mivalue,pmivalue,longcutsolution]=[0,0,np.array([self.longlength])]
            self.mivalue.append(mivalue)
            self.pmivalue.append(pmivalue)
            self.cut.append(longcutsolution-1)
            peakcollect = []
            noiselength = []
            noiseindex = []
            chances=[]
            for j in range(0,len(longcutsolution)):
                oriindex=np.where(self.denselongabs[0:int(longcutsolution[j])] <= self.threshold[i])[0]
                [nindex,chance]=findnoise(oriindex,self.dataindexinlong,self.dataindexindense,longcutsolution[j]-1)
                noiseindex.append(nindex)
                chances.append(chance)
                noiselength.append(len(noiseindex[j]))
                if (longcutsolution[j] == self.longlength):
                    peakcollect.append(0)
                else:
                    peakcollect.append(
                        self.denselongdata[self.longextremeall[int(np.where(self.longextremeall > longcutsolution[j] - 1)[0][0])]])
                    #extreme1value=self.denselongdata[self.longextremeall[int(np.where(self.longextremeall > longcutsolution[j] - 1)[0][0])]]
                    #zerotransitionpoint=longcutsolution[j]+int(np.where(np.sign(self.denselongdata[longcutsolution[j]:]) != np.sign(extreme1value))[0][0])
                    #extremepoint=longcutsolution[j]+int(np.where(self.denselongabs[longcutsolution[j]:zerotransitionpoint]==np.max(self.denselongabs[longcutsolution[j]:zerotransitionpoint]))[0][0])
                    #peakcollect.append(self.denselongdata[extremepoint])
            self.peak.append(peakcollect)
            self.noiselength.append(noiselength)
            self.noiseindex.append(noiseindex)
            self.chances.append(chances)

    def constructstate(self):
        state = State.State(self.name)
        for i in range(0,len(self.threshold)):
                if(i==len(self.threshold)-1):
                    downthreshold = self.threshold[i]
                    upthreshold=np.inf
                else:
                    downthreshold = self.threshold[i]
                    upthreshold = self.threshold[i + 1]
                if(len(self.noiselength[i])>1):
                    noisecombo=[]
                    for j in range(0,len(self.noiselength[i])):
                        noisecombo.append(self.densedata[self.noiseindex[i][j].astype('int')])
                    state.addcombo(len(self.noiselength[i]), downthreshold,upthreshold, noisecombo,self.chances[i], self.pmivalue[i], self.peak[i],self.longtimestamp[self.cut[i]])
                else:
                    state.addstate(downthreshold,upthreshold, self.densedata[self.noiseindex[i][0].astype('int')], self.chances[i],self.pmivalue[i], self.peak[i],self.longtimestamp[self.cut[i]])
        return state

def findnoise(oriindex,dataindexinlong,dataindexindense,cutsolution):
    noiseindex=np.array([])
    distributionrange=[]
    if(cutsolution==dataindexinlong[-1]):
        return np.arange(0,dataindexindense[-1]+1),len(dataindexindense)-1
    else:
        for i in range(0,len(dataindexinlong)-1):
            if(i<len(dataindexinlong)-2):
                haveornot = np.where((oriindex>=dataindexinlong[i]) & (oriindex<dataindexinlong[i+1]))[0]
            else:
                haveornot = np.where((oriindex >= dataindexinlong[i]) & (oriindex <= dataindexinlong[i + 1]))[0]
            if(len(haveornot>0)):
                distributionrange.append(i)
        if(len(distributionrange)==1):
            #return np.arange(dataindexinlong[distributionrange[0]+1])[dataindexinlong[distributionrange[0]]:dataindexinlong[distributionrange[0]+1]]
            return np.arange(dataindexindense[distributionrange[0]],dataindexindense[distributionrange[0]+1]+1),1
        else:
            for i in range(0,len(distributionrange)-1):
                noiseindex=np.append(noiseindex,np.arange(dataindexindense[distributionrange[i]], dataindexindense[distributionrange[i] + 1]+1))
            return np.sort(np.unique(noiseindex)),len(distributionrange)
