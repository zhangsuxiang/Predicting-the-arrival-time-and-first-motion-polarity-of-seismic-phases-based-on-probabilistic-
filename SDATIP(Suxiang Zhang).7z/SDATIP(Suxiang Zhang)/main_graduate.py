import os
import glob
import multiprocessing as mp
import obspy
from Waveform import Waveform
from single import solutionset

# 输入和输出目录
input_dir = './input'
output_dir = './output'
# 确保输出目录存在
os.makedirs(output_dir, exist_ok=True)

def process_sac_file(sac_path):
    """
    读取单个 SAC 文件，提取波形数据，并调用 solutionset 处理。
    输出的文件和图片将以 SAC 文件名（不含扩展名）为前缀。
    """
    try:
        # 读取 SAC
        st = obspy.read(sac_path)
        data = st[0].data
        # 去除路径和扩展名，作为名称前缀
        base_name = os.path.splitext(os.path.basename(sac_path))[0]
        # 调用 solutionset
        solutionset(base_name, data, output_dir)
    except Exception as e:
        print(f"Error processing {sac_path}: {e}")


def main():
    # 查找所有 SAC 文件
    sac_files = glob.glob(os.path.join(input_dir, '*.SAC'))
    if not sac_files:
        print(f"No SAC files found in {input_dir}")
        return

    # 并行处理
    cpu_count = mp.cpu_count()
    with mp.Pool(processes=cpu_count) as pool:
        pool.map(process_sac_file, sac_files)


if __name__ == '__main__':
    # Windows 下安全启动多进程
    mp.freeze_support()
    main()
